
# Add evidence trails, fraud-ring analysis, and grounded question generation

This plan tightens the investigation workbench so a human investigator can
trust every signal, trace it back to a source document, see fraud-ring
patterns, and walk through a single ranked question list to close the case.

## 1. Evidence trail on rules and contradictions

Every triggered rule and contradiction must point to the underlying
field(s) and fact(s) it was derived from, which already point to a source
document. Today rules carry only an `evidence` JSON blob and contradictions
carry `facts_involved` / `documents_involved` as loose JSON.

Changes:

- **Schema (migration):**
  - `triggered_rules`: add `source_fact_ids uuid[]`, `source_field_ids uuid[]`, `source_document_ids uuid[]`, `min_source_confidence numeric`.
  - `contradictions`: add `source_fact_ids uuid[]`, `source_field_ids uuid[]`, `source_document_ids uuid[]`, `min_source_confidence numeric`.
  - Keep the existing `evidence` / `facts_involved` JSON for backwards-compatible display.
- **Scenarios (`src/lib/scenarios.ts`):**
  - Extend `triggered_rules[]` entries with `source_fact_keys: string[]` and `source_field_names: string[]`.
  - Wire contradictions the same way (they already reference `fact_key` via `sides`).
- **Pipeline (`src/lib/pipeline.functions.ts`):**
  - After facts/fields are persisted, resolve those keys to row UUIDs and write the new array columns.
  - Compute `min_source_confidence` as the minimum confidence across all referenced facts and fields.
- **UI (`claims.$claimId.rules.tsx`, `claims.$claimId.contradictions.tsx`):**
  - For each row, render an "Evidence" expander listing each source field/fact with its confidence and a link/anchor to the source document (reuse `Documents` tab + scroll to doc id).
  - Replace the current "Show evidence" raw JSON with this structured trail (keep raw JSON behind a "Raw" toggle for power users).

## 2. Low-confidence verification flags

When a rule or contradiction depends on low-confidence extractions, surface
that visibly so the human re-checks the source snippet.

- Threshold: `min_source_confidence < 0.75` → render a `Verify source` warning chip on the rule/contradiction row, with a tooltip explaining "Derived from low-confidence extraction; re-check source document."
- Add the same chip on any question generated from that rule/contradiction (see §4).
- On the Fields and Facts tabs, add a "Low confidence" filter pill (already partially available via sort) and visually mark rows where `confidence < 0.75`.

## 3. Fraud Ring tab

A new top-level tab in the claim subnav (between Entities and Score) that
synthesizes fraud-ring patterns from historical entity matches.

- **Route:** `src/routes/claims.$claimId.fraud-ring.tsx`. Add to `claim-subnav.tsx` with a `Users` icon.
- **Server fn:** `getFraudRing(claimId)` in `claim-detail.functions.ts`.
  - Read `resolved_entities` + `entity_edges` (historical_match) + `historical_claims`.
  - Group historical claims that share ≥2 resolved entities with the current claim (e.g. same garage + same driver, or same vehicle + same hospital).
  - For each cluster, compute: shared entity set, list of historical claim IDs, count of suspicious flags, dominant `risk_category`, common `pattern_notes`.
- **Pattern detector (lightweight, rule-based):**
  - "Repeat garage ring": same garage appears on ≥3 historical suspicious claims.
  - "Driver-claimant swap": same person appears as driver in some claims and claimant in others.
  - "Hospital-garage pairing": same (hospital, garage) tuple recurring.
  - Each detected pattern carries a severity (low/medium/high) and a short explanation.
- **UI:** one card per detected pattern with: pattern name, severity badge, list of shared entities (clickable → Entities tab), list of historical claim IDs (clickable → Historical page), one-line explanation, and a "Use in questions" indicator showing this pattern fed question generation.
- **Persistence:** store detected patterns in a new `fraud_ring_patterns` table (`claim_id`, `pattern_type`, `severity`, `description`, `shared_entity_ids jsonb`, `historical_claim_ids jsonb`, `confidence`) so questions can reference them by id.

## 4. Grounded Investigation Questions (rebuild)

Replace the current free-floating `proactive_questions` list with a richer,
grounded list that is the investigator's single worklist.

- **Schema migration on `proactive_questions`:**
  - Add `source_type text` (`rule` | `contradiction` | `fraud_ring` | `auxiliary`).
  - Add `source_rule_id uuid`, `source_contradiction_id uuid`, `source_fraud_pattern_id uuid` (nullable).
  - Add `directed_to text` (e.g. `Insured`, `Garage`, `Hospital`, `Driver`, `Internal`).
  - Add `next_steps jsonb` — array of structured actions, e.g. `[{type:"collect_document", document_type:"FIR"}, {type:"call", party:"Insured"}, {type:"site_visit", location:"Garage"}]`.
  - Add `min_source_confidence numeric` (carry-through from the originating rule/contradiction so the Verify-source chip works here too).
- **Generator (`pipeline.functions.ts`, `questions.generate` tool):**
  - For each triggered rule → one or more questions tagged `source_type='rule'` linked back via `source_rule_id`, with `directed_to`/`next_steps` derived from rule category.
  - For each contradiction → questions tagged `source_type='contradiction'` linked via `source_contradiction_id`.
  - For each detected fraud-ring pattern → questions tagged `source_type='fraud_ring'` linked via `source_fraud_pattern_id`.
  - Add a final "Auxiliary" pass: LLM-style (mocked in scenarios for now) questions tagged `source_type='auxiliary'` that seek additional evidence not tied to a specific signal.
  - Scenarios get an authoring helper so each demo scenario lists rule-/contradiction-/ring-derived and auxiliary questions explicitly.
- **UI — new route `claims.$claimId.questions.tsx`** (replaces the inline list on the Score page; keep a short "Top 3" preview on Score that links here):
  - Tabbed/grouped view: `Rule-based`, `Contradiction-based`, `Fraud-ring`, `Auxiliary` with counts.
  - Each question card shows: question text, priority badge, `Directed to` chip, ordered `Next steps` list, a "Why" panel that renders the linked rule/contradiction/fraud-pattern summary (clickable → respective tab), and the Verify-source chip when `min_source_confidence < 0.75`.
  - Add to `claim-subnav.tsx` between Score and Output with a `HelpCircle` icon.

## 5. Final JSON payload

Extend the Supervisor's `final_payload` (in `sqc_results.final_payload`) so
the downstream system receives the new structure:

- `triggered_rules[].source_facts`, `source_fields`, `source_documents`, `min_source_confidence`.
- `contradictions[]` same enrichment.
- `fraud_ring_patterns[]` block.
- `questions[]` reshaped with `source_type`, `source_ref`, `directed_to`, `next_steps`, `min_source_confidence`.

## Out of scope

- Real LLM-based question generation (still scenario-driven mocks; covered by the earlier Step 10 plan).
- Editable questions / investigator notes UI — read-only for now.
- Re-running detection when historical data changes after a pipeline run.

## Suggested implementation order

1. Migration for evidence-trail columns + `fraud_ring_patterns` + `proactive_questions` columns.
2. Update scenarios authoring shape (rules/contradictions/questions carry source keys; add fraud-ring patterns and auxiliary questions per scenario).
3. Pipeline: persist evidence trails, detect fraud-ring patterns, rebuild question generator.
4. Server fns: `getFraudRing`, extend existing detail fns to return new fields.
5. UI: evidence expanders + low-confidence chips on Rules & Contradictions.
6. UI: new Fraud Ring tab.
7. UI: new Questions tab + trim Score page to a Top-3 preview.
8. Extend final JSON payload + Output tab renders the richer shape.
