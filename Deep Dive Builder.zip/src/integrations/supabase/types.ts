export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      app_config: {
        Row: {
          key: string
          updated_at: string
          value: Json
        }
        Insert: {
          key: string
          updated_at?: string
          value: Json
        }
        Update: {
          key?: string
          updated_at?: string
          value?: Json
        }
        Relationships: []
      }
      claim_documents: {
        Row: {
          claim_id: string
          classification_confidence: number | null
          created_at: string
          detected_language: string | null
          document_type: string
          extracted_text: string | null
          file_name: string
          id: string
          status: string
          storage_path: string | null
          translated_text: string | null
          translation_required: boolean | null
          warnings: Json | null
        }
        Insert: {
          claim_id: string
          classification_confidence?: number | null
          created_at?: string
          detected_language?: string | null
          document_type: string
          extracted_text?: string | null
          file_name: string
          id?: string
          status?: string
          storage_path?: string | null
          translated_text?: string | null
          translation_required?: boolean | null
          warnings?: Json | null
        }
        Update: {
          claim_id?: string
          classification_confidence?: number | null
          created_at?: string
          detected_language?: string | null
          document_type?: string
          extracted_text?: string | null
          file_name?: string
          id?: string
          status?: string
          storage_path?: string | null
          translated_text?: string | null
          translation_required?: boolean | null
          warnings?: Json | null
        }
        Relationships: [
          {
            foreignKeyName: "claim_documents_claim_id_fkey"
            columns: ["claim_id"]
            isOneToOne: false
            referencedRelation: "claims"
            referencedColumns: ["id"]
          },
        ]
      }
      claims: {
        Row: {
          claim_amount: number | null
          claim_id: string
          claim_type: string
          claimant_name: string | null
          created_at: string
          demo_scenario: string | null
          driver_name: string | null
          garage_name: string | null
          hospital_name: string | null
          id: string
          incident_date: string | null
          incident_location: string | null
          incident_time: string | null
          insured_name: string | null
          is_demo: boolean
          policy_end_date: string | null
          policy_number: string | null
          policy_start_date: string | null
          status: string
          vehicle_registration_number: string | null
        }
        Insert: {
          claim_amount?: number | null
          claim_id: string
          claim_type?: string
          claimant_name?: string | null
          created_at?: string
          demo_scenario?: string | null
          driver_name?: string | null
          garage_name?: string | null
          hospital_name?: string | null
          id?: string
          incident_date?: string | null
          incident_location?: string | null
          incident_time?: string | null
          insured_name?: string | null
          is_demo?: boolean
          policy_end_date?: string | null
          policy_number?: string | null
          policy_start_date?: string | null
          status?: string
          vehicle_registration_number?: string | null
        }
        Update: {
          claim_amount?: number | null
          claim_id?: string
          claim_type?: string
          claimant_name?: string | null
          created_at?: string
          demo_scenario?: string | null
          driver_name?: string | null
          garage_name?: string | null
          hospital_name?: string | null
          id?: string
          incident_date?: string | null
          incident_location?: string | null
          incident_time?: string | null
          insured_name?: string | null
          is_demo?: boolean
          policy_end_date?: string | null
          policy_number?: string | null
          policy_start_date?: string | null
          status?: string
          vehicle_registration_number?: string | null
        }
        Relationships: []
      }
      contradictions: {
        Row: {
          claim_id: string
          contradiction_type: string
          created_at: string
          description: string
          documents_involved: Json | null
          explanation: string | null
          facts_involved: Json | null
          id: string
          min_source_confidence: number | null
          recommended_followup: string | null
          severity: string
          source_document_ids: string[] | null
          source_fact_ids: string[] | null
          source_field_ids: string[] | null
        }
        Insert: {
          claim_id: string
          contradiction_type: string
          created_at?: string
          description: string
          documents_involved?: Json | null
          explanation?: string | null
          facts_involved?: Json | null
          id?: string
          min_source_confidence?: number | null
          recommended_followup?: string | null
          severity: string
          source_document_ids?: string[] | null
          source_fact_ids?: string[] | null
          source_field_ids?: string[] | null
        }
        Update: {
          claim_id?: string
          contradiction_type?: string
          created_at?: string
          description?: string
          documents_involved?: Json | null
          explanation?: string | null
          facts_involved?: Json | null
          id?: string
          min_source_confidence?: number | null
          recommended_followup?: string | null
          severity?: string
          source_document_ids?: string[] | null
          source_fact_ids?: string[] | null
          source_field_ids?: string[] | null
        }
        Relationships: [
          {
            foreignKeyName: "contradictions_claim_id_fkey"
            columns: ["claim_id"]
            isOneToOne: false
            referencedRelation: "claims"
            referencedColumns: ["id"]
          },
        ]
      }
      document_checklist: {
        Row: {
          claim_id: string
          created_at: string
          document_type: string
          id: string
          mandatory: boolean
          reason: string | null
          status: string
          suggested_source: string | null
          trigger_reference: string | null
        }
        Insert: {
          claim_id: string
          created_at?: string
          document_type: string
          id?: string
          mandatory?: boolean
          reason?: string | null
          status?: string
          suggested_source?: string | null
          trigger_reference?: string | null
        }
        Update: {
          claim_id?: string
          created_at?: string
          document_type?: string
          id?: string
          mandatory?: boolean
          reason?: string | null
          status?: string
          suggested_source?: string | null
          trigger_reference?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "document_checklist_claim_id_fkey"
            columns: ["claim_id"]
            isOneToOne: false
            referencedRelation: "claims"
            referencedColumns: ["id"]
          },
        ]
      }
      entity_edges: {
        Row: {
          claim_id: string
          created_at: string
          id: string
          properties: Json | null
          relationship_type: string
          source_node_id: string
          target_node_id: string
        }
        Insert: {
          claim_id: string
          created_at?: string
          id?: string
          properties?: Json | null
          relationship_type: string
          source_node_id: string
          target_node_id: string
        }
        Update: {
          claim_id?: string
          created_at?: string
          id?: string
          properties?: Json | null
          relationship_type?: string
          source_node_id?: string
          target_node_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "entity_edges_claim_id_fkey"
            columns: ["claim_id"]
            isOneToOne: false
            referencedRelation: "claims"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "entity_edges_source_node_id_fkey"
            columns: ["source_node_id"]
            isOneToOne: false
            referencedRelation: "entity_nodes"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "entity_edges_target_node_id_fkey"
            columns: ["target_node_id"]
            isOneToOne: false
            referencedRelation: "entity_nodes"
            referencedColumns: ["id"]
          },
        ]
      }
      entity_nodes: {
        Row: {
          claim_id: string
          created_at: string
          id: string
          label: string
          node_key: string
          node_type: string
          properties: Json | null
          raw_mention: string | null
          resolved_entity_id: string | null
          source_document_id: string | null
          source_fact_id: string | null
          source_field_id: string | null
        }
        Insert: {
          claim_id: string
          created_at?: string
          id?: string
          label: string
          node_key: string
          node_type: string
          properties?: Json | null
          raw_mention?: string | null
          resolved_entity_id?: string | null
          source_document_id?: string | null
          source_fact_id?: string | null
          source_field_id?: string | null
        }
        Update: {
          claim_id?: string
          created_at?: string
          id?: string
          label?: string
          node_key?: string
          node_type?: string
          properties?: Json | null
          raw_mention?: string | null
          resolved_entity_id?: string | null
          source_document_id?: string | null
          source_fact_id?: string | null
          source_field_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "entity_nodes_claim_id_fkey"
            columns: ["claim_id"]
            isOneToOne: false
            referencedRelation: "claims"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "entity_nodes_resolved_entity_id_fkey"
            columns: ["resolved_entity_id"]
            isOneToOne: false
            referencedRelation: "resolved_entities"
            referencedColumns: ["id"]
          },
        ]
      }
      extracted_facts: {
        Row: {
          claim_id: string
          confidence: number | null
          created_at: string
          fact_text: string
          fact_type: string | null
          id: string
          source_document_id: string
          source_field_ids: Json | null
          used_in_contradiction: boolean | null
          used_in_rule: boolean | null
        }
        Insert: {
          claim_id: string
          confidence?: number | null
          created_at?: string
          fact_text: string
          fact_type?: string | null
          id?: string
          source_document_id: string
          source_field_ids?: Json | null
          used_in_contradiction?: boolean | null
          used_in_rule?: boolean | null
        }
        Update: {
          claim_id?: string
          confidence?: number | null
          created_at?: string
          fact_text?: string
          fact_type?: string | null
          id?: string
          source_document_id?: string
          source_field_ids?: Json | null
          used_in_contradiction?: boolean | null
          used_in_rule?: boolean | null
        }
        Relationships: [
          {
            foreignKeyName: "extracted_facts_claim_id_fkey"
            columns: ["claim_id"]
            isOneToOne: false
            referencedRelation: "claims"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "extracted_facts_source_document_id_fkey"
            columns: ["source_document_id"]
            isOneToOne: false
            referencedRelation: "claim_documents"
            referencedColumns: ["id"]
          },
        ]
      }
      extracted_fields: {
        Row: {
          claim_id: string
          confidence: number | null
          created_at: string
          document_id: string
          field_name: string
          field_uuid: string
          id: string
          normalized_value: string | null
          raw_value: string | null
          source_language: string | null
          used_in_rule: boolean | null
        }
        Insert: {
          claim_id: string
          confidence?: number | null
          created_at?: string
          document_id: string
          field_name: string
          field_uuid: string
          id?: string
          normalized_value?: string | null
          raw_value?: string | null
          source_language?: string | null
          used_in_rule?: boolean | null
        }
        Update: {
          claim_id?: string
          confidence?: number | null
          created_at?: string
          document_id?: string
          field_name?: string
          field_uuid?: string
          id?: string
          normalized_value?: string | null
          raw_value?: string | null
          source_language?: string | null
          used_in_rule?: boolean | null
        }
        Relationships: [
          {
            foreignKeyName: "extracted_fields_claim_id_fkey"
            columns: ["claim_id"]
            isOneToOne: false
            referencedRelation: "claims"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "extracted_fields_document_id_fkey"
            columns: ["document_id"]
            isOneToOne: false
            referencedRelation: "claim_documents"
            referencedColumns: ["id"]
          },
        ]
      }
      fraud_ring_patterns: {
        Row: {
          claim_id: string
          confidence: number | null
          created_at: string
          description: string | null
          explanation: string | null
          historical_claim_ids: Json
          id: string
          pattern_name: string
          pattern_type: string
          severity: string
          shared_entity_ids: Json
        }
        Insert: {
          claim_id: string
          confidence?: number | null
          created_at?: string
          description?: string | null
          explanation?: string | null
          historical_claim_ids?: Json
          id?: string
          pattern_name: string
          pattern_type: string
          severity: string
          shared_entity_ids?: Json
        }
        Update: {
          claim_id?: string
          confidence?: number | null
          created_at?: string
          description?: string | null
          explanation?: string | null
          historical_claim_ids?: Json
          id?: string
          pattern_name?: string
          pattern_type?: string
          severity?: string
          shared_entity_ids?: Json
        }
        Relationships: []
      }
      historical_claims: {
        Row: {
          claim_amount: number | null
          claim_type: string | null
          claimant_name: string | null
          created_at: string
          driver_name: string | null
          garage_name: string | null
          historical_claim_id: string
          hospital_name: string | null
          id: string
          incident_date: string | null
          incident_location: string | null
          investigation_outcome: string | null
          pattern_notes: string | null
          risk_category: string | null
          suspicious_flag: boolean | null
          vehicle_registration_number: string | null
        }
        Insert: {
          claim_amount?: number | null
          claim_type?: string | null
          claimant_name?: string | null
          created_at?: string
          driver_name?: string | null
          garage_name?: string | null
          historical_claim_id: string
          hospital_name?: string | null
          id?: string
          incident_date?: string | null
          incident_location?: string | null
          investigation_outcome?: string | null
          pattern_notes?: string | null
          risk_category?: string | null
          suspicious_flag?: boolean | null
          vehicle_registration_number?: string | null
        }
        Update: {
          claim_amount?: number | null
          claim_type?: string | null
          claimant_name?: string | null
          created_at?: string
          driver_name?: string | null
          garage_name?: string | null
          historical_claim_id?: string
          hospital_name?: string | null
          id?: string
          incident_date?: string | null
          incident_location?: string | null
          investigation_outcome?: string | null
          pattern_notes?: string | null
          risk_category?: string | null
          suspicious_flag?: boolean | null
          vehicle_registration_number?: string | null
        }
        Relationships: []
      }
      job_events: {
        Row: {
          agent_name: string | null
          claim_id: string | null
          completed_at: string | null
          created_at: string
          id: string
          job_id: string
          message: string | null
          payload: Json | null
          phase: string | null
          skill_applied: string | null
          started_at: string | null
          status: string
          tool_used: string | null
        }
        Insert: {
          agent_name?: string | null
          claim_id?: string | null
          completed_at?: string | null
          created_at?: string
          id?: string
          job_id: string
          message?: string | null
          payload?: Json | null
          phase?: string | null
          skill_applied?: string | null
          started_at?: string | null
          status: string
          tool_used?: string | null
        }
        Update: {
          agent_name?: string | null
          claim_id?: string | null
          completed_at?: string | null
          created_at?: string
          id?: string
          job_id?: string
          message?: string | null
          payload?: Json | null
          phase?: string | null
          skill_applied?: string | null
          started_at?: string | null
          status?: string
          tool_used?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "job_events_claim_id_fkey"
            columns: ["claim_id"]
            isOneToOne: false
            referencedRelation: "claims"
            referencedColumns: ["id"]
          },
        ]
      }
      master_rules: {
        Row: {
          category: string
          created_at: string
          data_required: Json | null
          description: string | null
          id: string
          is_active: boolean
          rule_id: string
          rule_name: string
          rule_type: string | null
          severity: string
          source: string
          threshold_config: Json | null
          used_in_demo: boolean
        }
        Insert: {
          category: string
          created_at?: string
          data_required?: Json | null
          description?: string | null
          id?: string
          is_active?: boolean
          rule_id: string
          rule_name: string
          rule_type?: string | null
          severity: string
          source?: string
          threshold_config?: Json | null
          used_in_demo?: boolean
        }
        Update: {
          category?: string
          created_at?: string
          data_required?: Json | null
          description?: string | null
          id?: string
          is_active?: boolean
          rule_id?: string
          rule_name?: string
          rule_type?: string | null
          severity?: string
          source?: string
          threshold_config?: Json | null
          used_in_demo?: boolean
        }
        Relationships: []
      }
      proactive_questions: {
        Row: {
          claim_id: string
          created_at: string
          directed_to: string | null
          id: string
          min_source_confidence: number | null
          next_steps: Json | null
          priority: string | null
          question: string
          rationale: string | null
          source_contradiction_id: string | null
          source_fraud_pattern_id: string | null
          source_rule_id: string | null
          source_type: string | null
          target: string | null
          trigger_reference: string | null
        }
        Insert: {
          claim_id: string
          created_at?: string
          directed_to?: string | null
          id?: string
          min_source_confidence?: number | null
          next_steps?: Json | null
          priority?: string | null
          question: string
          rationale?: string | null
          source_contradiction_id?: string | null
          source_fraud_pattern_id?: string | null
          source_rule_id?: string | null
          source_type?: string | null
          target?: string | null
          trigger_reference?: string | null
        }
        Update: {
          claim_id?: string
          created_at?: string
          directed_to?: string | null
          id?: string
          min_source_confidence?: number | null
          next_steps?: Json | null
          priority?: string | null
          question?: string
          rationale?: string | null
          source_contradiction_id?: string | null
          source_fraud_pattern_id?: string | null
          source_rule_id?: string | null
          source_type?: string | null
          target?: string | null
          trigger_reference?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "proactive_questions_claim_id_fkey"
            columns: ["claim_id"]
            isOneToOne: false
            referencedRelation: "claims"
            referencedColumns: ["id"]
          },
        ]
      }
      resolved_entities: {
        Row: {
          canonical_value: string
          claim_id: string
          confidence: number | null
          created_at: string
          entity_type: string
          id: string
          resolution_method: string | null
        }
        Insert: {
          canonical_value: string
          claim_id: string
          confidence?: number | null
          created_at?: string
          entity_type: string
          id?: string
          resolution_method?: string | null
        }
        Update: {
          canonical_value?: string
          claim_id?: string
          confidence?: number | null
          created_at?: string
          entity_type?: string
          id?: string
          resolution_method?: string | null
        }
        Relationships: []
      }
      skills: {
        Row: {
          applied_by_agent: string | null
          id: string
          instructions: string | null
          purpose: string | null
          skill_name: string
          updated_at: string
        }
        Insert: {
          applied_by_agent?: string | null
          id?: string
          instructions?: string | null
          purpose?: string | null
          skill_name: string
          updated_at?: string
        }
        Update: {
          applied_by_agent?: string | null
          id?: string
          instructions?: string | null
          purpose?: string | null
          skill_name?: string
          updated_at?: string
        }
        Relationships: []
      }
      sqc_results: {
        Row: {
          claim_id: string
          component_scores: Json | null
          created_at: string
          final_payload: Json | null
          id: string
          job_id: string
          key_findings: Json | null
          narrative: string | null
          recommended_action: string | null
          risk_category: string | null
          risk_score: number
          status: string
        }
        Insert: {
          claim_id: string
          component_scores?: Json | null
          created_at?: string
          final_payload?: Json | null
          id?: string
          job_id: string
          key_findings?: Json | null
          narrative?: string | null
          recommended_action?: string | null
          risk_category?: string | null
          risk_score?: number
          status?: string
        }
        Update: {
          claim_id?: string
          component_scores?: Json | null
          created_at?: string
          final_payload?: Json | null
          id?: string
          job_id?: string
          key_findings?: Json | null
          narrative?: string | null
          recommended_action?: string | null
          risk_category?: string | null
          risk_score?: number
          status?: string
        }
        Relationships: [
          {
            foreignKeyName: "sqc_results_claim_id_fkey"
            columns: ["claim_id"]
            isOneToOne: false
            referencedRelation: "claims"
            referencedColumns: ["id"]
          },
        ]
      }
      tools_registry: {
        Row: {
          contains_reasoning: boolean
          created_at: string
          description: string | null
          deterministic: boolean
          id: string
          input_schema: Json | null
          output_schema: Json | null
          tool_name: string
        }
        Insert: {
          contains_reasoning?: boolean
          created_at?: string
          description?: string | null
          deterministic?: boolean
          id?: string
          input_schema?: Json | null
          output_schema?: Json | null
          tool_name: string
        }
        Update: {
          contains_reasoning?: boolean
          created_at?: string
          description?: string | null
          deterministic?: boolean
          id?: string
          input_schema?: Json | null
          output_schema?: Json | null
          tool_name?: string
        }
        Relationships: []
      }
      triggered_rules: {
        Row: {
          category: string | null
          claim_id: string
          confidence: number | null
          created_at: string
          description: string | null
          evidence: Json | null
          id: string
          min_source_confidence: number | null
          rule_id: string
          rule_name: string
          severity: string
          source_document_ids: string[] | null
          source_fact_ids: string[] | null
          source_field_ids: string[] | null
        }
        Insert: {
          category?: string | null
          claim_id: string
          confidence?: number | null
          created_at?: string
          description?: string | null
          evidence?: Json | null
          id?: string
          min_source_confidence?: number | null
          rule_id: string
          rule_name: string
          severity: string
          source_document_ids?: string[] | null
          source_fact_ids?: string[] | null
          source_field_ids?: string[] | null
        }
        Update: {
          category?: string | null
          claim_id?: string
          confidence?: number | null
          created_at?: string
          description?: string | null
          evidence?: Json | null
          id?: string
          min_source_confidence?: number | null
          rule_id?: string
          rule_name?: string
          severity?: string
          source_document_ids?: string[] | null
          source_fact_ids?: string[] | null
          source_field_ids?: string[] | null
        }
        Relationships: [
          {
            foreignKeyName: "triggered_rules_claim_id_fkey"
            columns: ["claim_id"]
            isOneToOne: false
            referencedRelation: "claims"
            referencedColumns: ["id"]
          },
        ]
      }
      uploaded_master_rules: {
        Row: {
          batch_id: string
          category: string
          created_at: string
          data_required: Json | null
          description: string | null
          id: string
          rule_id: string
          rule_name: string
          rule_type: string | null
          severity: string
        }
        Insert: {
          batch_id: string
          category: string
          created_at?: string
          data_required?: Json | null
          description?: string | null
          id?: string
          rule_id: string
          rule_name: string
          rule_type?: string | null
          severity: string
        }
        Update: {
          batch_id?: string
          category?: string
          created_at?: string
          data_required?: Json | null
          description?: string | null
          id?: string
          rule_id?: string
          rule_name?: string
          rule_type?: string | null
          severity?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
