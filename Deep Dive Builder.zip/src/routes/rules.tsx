import { createFileRoute } from "@tanstack/react-router";
import { ComingSoon } from "@/components/coming-soon";

export const Route = createFileRoute("/rules")({
  component: () => (
    <ComingSoon
      title="Rules & Triggers"
      description="40 seeded master rules across 13 categories, plus the active rule set used by the pipeline."
    />
  ),
});
