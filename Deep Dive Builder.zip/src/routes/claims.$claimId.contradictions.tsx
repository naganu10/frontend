import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { getContradictions } from "@/lib/claim-detail.functions";
import { ClaimSubnav } from "@/components/claim-subnav";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  ArrowLeft,
  PlayCircle,
  GitCompare,
  ShieldCheck,
  Lightbulb,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { EvidenceTrail, VerifyChip } from "@/components/evidence-trail";

export const Route = createFileRoute("/claims/$claimId/contradictions")({
  component: ContradictionsPage,
});

const SEVERITIES = ["critical", "high", "medium", "low"] as const;
type Severity = (typeof SEVERITIES)[number];

function severityTone(sev: string | null) {
  switch ((sev ?? "").toLowerCase()) {
    case "critical":
      return "bg-destructive text-destructive-foreground";
    case "high":
      return "bg-destructive/15 text-destructive";
    case "medium":
      return "bg-amber-500/15 text-amber-700 dark:text-amber-300";
    case "low":
      return "bg-muted text-muted-foreground";
    default:
      return "bg-muted text-muted-foreground";
  }
}

type Side = { side?: string; document_type?: string; fact_id?: string | null };

function asSides(value: unknown): Side[] {
  if (Array.isArray(value)) {
    return value.filter((v) => v && typeof v === "object") as Side[];
  }
  return [];
}


function ContradictionsPage() {
  const { claimId } = Route.useParams();
  const fetcher = useServerFn(getContradictions);
  const { data, isLoading } = useQuery({
    queryKey: ["contradictions", claimId],
    queryFn: () => fetcher({ data: { claimId } }),
  });

  const items = data?.contradictions ?? [];
  const [filter, setFilter] = useState<Severity | null>(null);
  const visible = useMemo(
    () =>
      filter
        ? items.filter((c) => (c.severity ?? "").toLowerCase() === filter)
        : items,
    [items, filter],
  );

  return (
    <div className="mx-auto w-full max-w-7xl space-y-6 p-6">
      <div>
        <Button asChild variant="ghost" size="sm" className="-ml-2 mb-2">
          <Link to="/jobs/$jobId" params={{ jobId: claimId }}>
            <ArrowLeft className="h-3 w-3" />
            Back to Execution Console
          </Link>
        </Button>
        <h1 className="text-2xl font-semibold tracking-tight">
          {isLoading ? "Loading…" : data?.claim?.claim_id}
        </h1>
        <p className="text-sm text-muted-foreground">Cross-Document Contradictions</p>
      </div>

      <ClaimSubnav claimId={claimId} active="contradictions" />

      <Card>
        <CardHeader>
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <CardTitle className="text-base">Detected Contradictions</CardTitle>
              <CardDescription>
                {items.length} contradiction{items.length === 1 ? "" : "s"} found between documents
              </CardDescription>
            </div>
            {items.length > 0 && (
              <div className="flex flex-wrap items-center gap-1.5">
                <FilterPill active={filter === null} onClick={() => setFilter(null)}>
                  All
                </FilterPill>
                {SEVERITIES.map((s) => {
                  const n = items.filter(
                    (c) => (c.severity ?? "").toLowerCase() === s,
                  ).length;
                  if (!n) return null;
                  return (
                    <FilterPill
                      key={s}
                      active={filter === s}
                      onClick={() => setFilter(s)}
                    >
                      {s} ({n})
                    </FilterPill>
                  );
                })}
              </div>
            )}
          </div>
        </CardHeader>
        <CardContent>
          {visible.length === 0 ? (
            <div className="flex flex-col items-center justify-center gap-3 py-12 text-center">
              <ShieldCheck className="h-8 w-8 text-emerald-500" />
              <p className="text-sm text-muted-foreground">
                {items.length === 0
                  ? "No contradictions detected on this claim."
                  : "No contradictions match the selected filter."}
              </p>
              {items.length === 0 && !isLoading && (
                <Button asChild size="sm" variant="ghost">
                  <Link to="/jobs/$jobId" params={{ jobId: claimId }}>
                    <PlayCircle className="h-3 w-3" />
                    Open Execution Console
                  </Link>
                </Button>
              )}
            </div>
          ) : (
            <div className="grid gap-3 lg:grid-cols-2">
              {visible.map((c) => {
                const sides = asSides(c.facts_involved);
                const a = sides[0];
                const b = sides[1];
                const cx = c as typeof c & {
                  source_facts?: import("@/components/evidence-trail").EvidenceFact[];
                  source_fields?: import("@/components/evidence-trail").EvidenceField[];
                  source_documents?: import("@/components/evidence-trail").EvidenceDoc[];
                  min_source_confidence?: number | null;
                };
                return (
                  <div
                    key={c.id}
                    className="space-y-3 rounded-md border p-4 transition-all hover:border-primary/40 hover:shadow-sm"
                  >
                    <div className="flex flex-wrap items-start justify-between gap-2">
                      <div className="flex items-start gap-2">
                        <GitCompare className="mt-0.5 h-4 w-4 shrink-0 text-muted-foreground" />
                        <div>
                          <div className="text-sm font-medium">{c.description}</div>
                          <div className="font-mono text-[11px] text-muted-foreground">
                            {c.contradiction_type}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <VerifyChip confidence={cx.min_source_confidence ?? null} />
                        <span
                          className={cn(
                            "rounded px-1.5 py-0.5 text-[10px] font-medium uppercase tracking-wide",
                            severityTone(c.severity),
                          )}
                        >
                          {c.severity}
                        </span>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                      <SidePanel label="Side A" doc={a?.document_type} />
                      <SidePanel label="Side B" doc={b?.document_type} />
                    </div>

                    {c.explanation && (
                      <p className="text-sm text-muted-foreground">{c.explanation}</p>
                    )}

                    <EvidenceTrail
                      facts={cx.source_facts}
                      fields={cx.source_fields}
                      documents={cx.source_documents}
                      minConfidence={cx.min_source_confidence ?? null}
                    />

                    {c.recommended_followup && (
                      <div className="flex items-start gap-2 rounded-md border border-primary/30 bg-primary/5 p-2.5">
                        <Lightbulb className="mt-0.5 h-3.5 w-3.5 shrink-0 text-primary" />
                        <div className="space-y-0.5">
                          <div className="text-[10px] font-medium uppercase tracking-wide text-primary">
                            Recommended follow-up
                          </div>
                          <p className="text-xs leading-relaxed">
                            {c.recommended_followup}
                          </p>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function SidePanel({ label, doc }: { label: string; doc?: string }) {
  return (
    <div className="rounded border bg-muted/30 p-2.5">
      <div className="mb-1 text-[10px] font-medium uppercase tracking-wide text-muted-foreground">
        {label}
      </div>
      <div className="font-mono text-xs leading-relaxed">{doc ?? "—"}</div>
    </div>
  );
}

function FilterPill({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "rounded-full border px-2.5 py-0.5 text-[11px] capitalize transition-colors",
        active
          ? "border-primary bg-primary/10 text-foreground"
          : "border-muted text-muted-foreground hover:border-primary/40 hover:text-foreground",
      )}
    >
      {children}
    </button>
  );
}
