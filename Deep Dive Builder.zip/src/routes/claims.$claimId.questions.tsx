import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { useMemo } from "react";
import { getInvestigationQuestions } from "@/lib/claim-detail.functions";
import { ClaimSubnav } from "@/components/claim-subnav";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, HelpCircle, ShieldAlert, GitCompare, Users, Sparkles } from "lucide-react";
import { cn } from "@/lib/utils";
import { VerifyChip } from "@/components/evidence-trail";

export const Route = createFileRoute("/claims/$claimId/questions")({
  component: QuestionsPage,
});

const SOURCE_META: Record<string, { label: string; icon: typeof HelpCircle; tone: string }> = {
  rule: { label: "From rule", icon: ShieldAlert, tone: "bg-red-500/10 text-red-700 dark:text-red-300" },
  contradiction: { label: "From contradiction", icon: GitCompare, tone: "bg-amber-500/10 text-amber-700 dark:text-amber-300" },
  fraud_ring: { label: "From fraud ring", icon: Users, tone: "bg-purple-500/10 text-purple-700 dark:text-purple-300" },
  auxiliary: { label: "Auxiliary", icon: Sparkles, tone: "bg-muted text-muted-foreground" },
};

const PRIORITY_ORDER: Record<string, number> = { high: 0, medium: 1, low: 2 };

function priorityTone(p: string | null) {
  switch ((p ?? "").toLowerCase()) {
    case "high":
      return "bg-destructive/15 text-destructive";
    case "medium":
      return "bg-amber-500/15 text-amber-700 dark:text-amber-300";
    default:
      return "bg-muted text-muted-foreground";
  }
}

type Q = Awaited<ReturnType<typeof getInvestigationQuestions>>["questions"][number];

function QuestionsPage() {
  const { claimId } = Route.useParams();
  const fetcher = useServerFn(getInvestigationQuestions);
  const { data, isLoading } = useQuery({
    queryKey: ["investigation-questions", claimId],
    queryFn: () => fetcher({ data: { claimId } }),
  });

  const questions = data?.questions ?? [];

  const grouped = useMemo(() => {
    const order: Array<keyof typeof SOURCE_META> = ["rule", "contradiction", "fraud_ring", "auxiliary"];
    const map = new Map<string, Q[]>();
    for (const q of questions) {
      const k = (q.source_type ?? "auxiliary") as string;
      if (!map.has(k)) map.set(k, []);
      map.get(k)!.push(q);
    }
    for (const arr of map.values()) {
      arr.sort((a, b) => (PRIORITY_ORDER[(a.priority ?? "").toLowerCase()] ?? 9) - (PRIORITY_ORDER[(b.priority ?? "").toLowerCase()] ?? 9));
    }
    return order.filter((k) => map.has(k)).map((k) => [k, map.get(k)!] as const);
  }, [questions]);

  return (
    <div className="mx-auto w-full max-w-7xl space-y-6 p-6">
      <div>
        <Button asChild variant="ghost" size="sm" className="-ml-2 mb-2">
          <Link to="/jobs/$jobId" params={{ jobId: claimId }}>
            <ArrowLeft className="h-3 w-3" />
            Back to Execution Console
          </Link>
        </Button>
        <h1 className="text-2xl font-semibold tracking-tight">
          {isLoading ? "Loading…" : data?.claim?.claim_id}
        </h1>
        <p className="text-sm text-muted-foreground">Investigation Questions</p>
      </div>

      <ClaimSubnav claimId={claimId} active="questions" />

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <HelpCircle className="h-4 w-4 text-primary" />
            Grounded questions
          </CardTitle>
          <CardDescription>
            {questions.length} question{questions.length === 1 ? "" : "s"} grouped by what triggered them
          </CardDescription>
        </CardHeader>
        <CardContent>
          {questions.length === 0 ? (
            <p className="py-12 text-center text-sm text-muted-foreground">No questions generated.</p>
          ) : (
            <div className="space-y-6">
              {grouped.map(([sourceType, items]) => {
                const meta = SOURCE_META[sourceType] ?? SOURCE_META.auxiliary;
                const Icon = meta.icon;
                return (
                  <div key={sourceType} className="space-y-2">
                    <div className="flex items-center gap-2">
                      <span className={cn("inline-flex items-center gap-1.5 rounded px-2 py-0.5 text-[11px] font-medium", meta.tone)}>
                        <Icon className="h-3 w-3" />
                        {meta.label}
                      </span>
                      <span className="text-[11px] text-muted-foreground">{items.length}</span>
                    </div>
                    <div className="space-y-2">
                      {items.map((q) => (
                        <QuestionCard key={q.id} q={q} />
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function QuestionCard({ q }: { q: Q }) {
  const nextSteps = (q.next_steps ?? []) as Array<Record<string, string>>;
  return (
    <div className="space-y-2 rounded-md border p-3">
      <div className="flex flex-wrap items-start justify-between gap-2">
        <p className="text-sm font-medium">{q.question}</p>
        <div className="flex items-center gap-1.5">
          <VerifyChip confidence={q.min_source_confidence as number | null} />
          <span className={cn("rounded px-1.5 py-0.5 text-[10px] font-medium uppercase tracking-wide", priorityTone(q.priority))}>
            {q.priority}
          </span>
        </div>
      </div>
      {q.rationale && <p className="text-xs italic text-muted-foreground">{q.rationale}</p>}
      <div className="flex flex-wrap items-center gap-3 text-[11px]">
        {q.directed_to && (
          <span className="text-muted-foreground">
            Directed to: <span className="font-medium text-foreground">{q.directed_to}</span>
          </span>
        )}
        {q.source_rule && (
          <Badge variant="outline" className="font-mono text-[10px]">{q.source_rule.rule_id}</Badge>
        )}
        {q.source_contradiction && (
          <Badge variant="outline" className="font-mono text-[10px]">{q.source_contradiction.contradiction_type}</Badge>
        )}
        {q.source_fraud_pattern && (
          <Badge variant="outline" className="font-mono text-[10px]">{q.source_fraud_pattern.pattern_type}</Badge>
        )}
      </div>
      {nextSteps.length > 0 && (
        <div className="rounded border bg-muted/30 p-2">
          <div className="mb-1 text-[10px] font-medium uppercase tracking-wide text-muted-foreground">Next steps</div>
          <ul className="space-y-0.5 text-[11px]">
            {nextSteps.map((s, i) => (
              <li key={i} className="flex flex-wrap gap-1.5">
                <span className="font-mono text-[10px] text-muted-foreground">{s.type}</span>
                {s.document_type && <span>collect <span className="font-medium">{s.document_type}</span></span>}
                {s.party && <span>contact <span className="font-medium">{s.party}</span></span>}
                {s.location && <span>at <span className="font-medium">{s.location}</span></span>}
                {s.detail && <span>{s.detail}</span>}
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
