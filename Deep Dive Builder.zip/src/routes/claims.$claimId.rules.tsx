import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { getTriggeredRules } from "@/lib/claim-detail.functions";
import { ClaimSubnav } from "@/components/claim-subnav";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  ArrowLeft,
  PlayCircle,
  ShieldAlert,
  ShieldCheck,
  ChevronDown,
  ChevronRight,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { EvidenceTrail, VerifyChip } from "@/components/evidence-trail";

export const Route = createFileRoute("/claims/$claimId/rules")({
  component: RulesPage,
});

const SEVERITY_ORDER: Record<string, number> = {
  critical: 0,
  high: 1,
  medium: 2,
  low: 3,
};

function severityTone(sev: string | null) {
  switch ((sev ?? "").toLowerCase()) {
    case "critical":
      return "bg-destructive text-destructive-foreground";
    case "high":
      return "bg-destructive/15 text-destructive";
    case "medium":
      return "bg-amber-500/15 text-amber-700 dark:text-amber-300";
    case "low":
      return "bg-muted text-muted-foreground";
    default:
      return "bg-muted text-muted-foreground";
  }
}

type Rule = Awaited<ReturnType<typeof getTriggeredRules>>["rules"][number];

function RulesPage() {
  const { claimId } = Route.useParams();
  const fetcher = useServerFn(getTriggeredRules);
  const { data, isLoading } = useQuery({
    queryKey: ["triggered-rules", claimId],
    queryFn: () => fetcher({ data: { claimId } }),
  });

  const rules = data?.rules ?? [];

  const counts = useMemo(() => {
    const c: Record<string, number> = { critical: 0, high: 0, medium: 0, low: 0 };
    rules.forEach((r) => {
      const k = (r.severity ?? "").toLowerCase();
      if (k in c) c[k] += 1;
    });
    return c;
  }, [rules]);

  const grouped = useMemo(() => {
    const map = new Map<string, Rule[]>();
    [...rules]
      .sort((a, b) => {
        const sa = SEVERITY_ORDER[(a.severity ?? "").toLowerCase()] ?? 9;
        const sb = SEVERITY_ORDER[(b.severity ?? "").toLowerCase()] ?? 9;
        if (sa !== sb) return sa - sb;
        return Number(b.confidence ?? 0) - Number(a.confidence ?? 0);
      })
      .forEach((r) => {
        const cat = r.category ?? "Uncategorized";
        if (!map.has(cat)) map.set(cat, []);
        map.get(cat)!.push(r);
      });
    return Array.from(map.entries());
  }, [rules]);

  return (
    <div className="mx-auto w-full max-w-7xl space-y-6 p-6">
      <div>
        <Button asChild variant="ghost" size="sm" className="-ml-2 mb-2">
          <Link to="/jobs/$jobId" params={{ jobId: claimId }}>
            <ArrowLeft className="h-3 w-3" />
            Back to Execution Console
          </Link>
        </Button>
        <h1 className="text-2xl font-semibold tracking-tight">
          {isLoading ? "Loading…" : data?.claim?.claim_id}
        </h1>
        <p className="text-sm text-muted-foreground">Triggered Rules</p>
      </div>

      <ClaimSubnav claimId={claimId} active="rules" />

      <Card>
        <CardHeader>
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <CardTitle className="text-base">Master Rule Hits</CardTitle>
              <CardDescription>
                {rules.length} rule{rules.length === 1 ? "" : "s"} triggered by the Analysis agent
              </CardDescription>
            </div>
            <div className="flex flex-wrap items-center gap-1.5">
              {(["critical", "high", "medium", "low"] as const).map((sev) => (
                <span
                  key={sev}
                  className={cn(
                    "rounded px-2 py-0.5 text-[10px] font-medium uppercase tracking-wide",
                    severityTone(sev),
                  )}
                >
                  {sev}: {counts[sev]}
                </span>
              ))}
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {rules.length === 0 ? (
            <div className="flex flex-col items-center justify-center gap-3 py-12 text-center">
              <ShieldCheck className="h-8 w-8 text-emerald-500" />
              <p className="text-sm text-muted-foreground">
                No rules triggered on this claim.
              </p>
              {!isLoading && (
                <Button asChild size="sm" variant="ghost">
                  <Link to="/jobs/$jobId" params={{ jobId: claimId }}>
                    <PlayCircle className="h-3 w-3" />
                    Open Execution Console
                  </Link>
                </Button>
              )}
            </div>
          ) : (
            <div className="space-y-4">
              {grouped.map(([category, items]) => (
                <CategoryGroup key={category} category={category} items={items} />
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function CategoryGroup({ category, items }: { category: string; items: Rule[] }) {
  const [open, setOpen] = useState(true);
  return (
    <div className="rounded-md border">
      <button
        onClick={() => setOpen((v) => !v)}
        className="flex w-full items-center justify-between gap-2 px-3 py-2 text-sm hover:bg-muted/40"
      >
        <span className="flex items-center gap-2 font-medium">
          {open ? (
            <ChevronDown className="h-3.5 w-3.5" />
          ) : (
            <ChevronRight className="h-3.5 w-3.5" />
          )}
          {category}
        </span>
        <span className="text-xs text-muted-foreground">{items.length}</span>
      </button>
      {open && (
        <div className="divide-y border-t">
          {items.map((r) => (
            <RuleRow key={r.id} rule={r} />
          ))}
        </div>
      )}
    </div>
  );
}

function RuleRow({ rule }: { rule: Rule }) {
  const conf = Math.round(Number(rule.confidence ?? 0) * 100);
  const r = rule as Rule & {
    source_facts?: import("@/components/evidence-trail").EvidenceFact[];
    source_fields?: import("@/components/evidence-trail").EvidenceField[];
    source_documents?: import("@/components/evidence-trail").EvidenceDoc[];
    min_source_confidence?: number | null;
  };
  return (
    <div className="space-y-2 p-3">
      <div className="flex flex-wrap items-start justify-between gap-2">
        <div className="flex items-start gap-2">
          <ShieldAlert className="mt-0.5 h-4 w-4 shrink-0 text-muted-foreground" />
          <div>
            <div className="text-sm font-medium">{rule.rule_name}</div>
            <div className="font-mono text-[11px] text-muted-foreground">{rule.rule_id}</div>
          </div>
        </div>
        <div className="flex items-center gap-1.5">
          <VerifyChip confidence={r.min_source_confidence ?? null} />
          <span
            className={cn(
              "rounded px-1.5 py-0.5 text-[10px] font-medium uppercase tracking-wide",
              severityTone(rule.severity),
            )}
          >
            {rule.severity}
          </span>
          <span className="rounded bg-muted px-1.5 py-0.5 font-mono text-[10px] text-muted-foreground">
            {conf}%
          </span>
        </div>
      </div>
      {(rule.description || rule.master_description) && (
        <p className="text-sm text-muted-foreground">
          {rule.description || rule.master_description}
        </p>
      )}
      <EvidenceTrail
        facts={r.source_facts}
        fields={r.source_fields}
        documents={r.source_documents}
        minConfidence={r.min_source_confidence ?? null}
      />
    </div>
  );
}
