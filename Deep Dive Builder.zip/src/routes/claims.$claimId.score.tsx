import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { getClaimScore } from "@/lib/claim-detail.functions";
import { ClaimSubnav } from "@/components/claim-subnav";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { ArrowLeft, Gauge, HelpCircle } from "lucide-react";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/claims/$claimId/score")({
  component: ScorePage,
});

const CATEGORY_TONE: Record<string, string> = {
  Low: "bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 border-emerald-500/30",
  Medium: "bg-amber-500/15 text-amber-700 dark:text-amber-300 border-amber-500/30",
  High: "bg-red-500/15 text-red-700 dark:text-red-300 border-red-500/30",
};

const ACTION_LABEL: Record<string, string> = {
  DESKTOP_REVIEW: "Desktop review",
  DESKTOP_INVESTIGATION: "Desktop investigation",
  FIELD_INVESTIGATION: "Field investigation",
};

function ScorePage() {
  const { claimId } = Route.useParams();
  const fetcher = useServerFn(getClaimScore);
  const { data, isLoading } = useQuery({
    queryKey: ["claim-score", claimId],
    queryFn: () => fetcher({ data: { claimId } }),
  });

  const sqc = data?.sqc;
  const components = (sqc?.component_scores ?? {}) as Record<string, number>;
  const findings = (sqc?.key_findings ?? []) as string[];
  const questions = data?.questions ?? [];

  return (
    <div className="mx-auto w-full max-w-7xl space-y-6 p-6">
      <div>
        <Button asChild variant="ghost" size="sm" className="-ml-2 mb-2">
          <Link to="/jobs/$jobId" params={{ jobId: claimId }}>
            <ArrowLeft className="h-3 w-3" />
            Back to Execution Console
          </Link>
        </Button>
        <h1 className="text-2xl font-semibold tracking-tight">
          {isLoading ? "Loading…" : data?.claim?.claim_id}
        </h1>
        <p className="text-sm text-muted-foreground">Claim Risk Score</p>
      </div>

      <ClaimSubnav claimId={claimId} active="score" />

      {!sqc ? (
        <Card>
          <CardContent className="py-12 text-center text-sm text-muted-foreground">
            No score yet. Run the pipeline first.
          </CardContent>
        </Card>
      ) : (
        <>
          <Card>
            <CardHeader>
              <div className="flex flex-wrap items-start justify-between gap-4">
                <div>
                  <CardTitle className="flex items-center gap-2 text-base">
                    <Gauge className="h-4 w-4 text-primary" />
                    Overall risk
                  </CardTitle>
                  <CardDescription>{ACTION_LABEL[sqc.recommended_action ?? ""] ?? sqc.recommended_action}</CardDescription>
                </div>
                <div className="flex items-center gap-4">
                  <div className="text-right">
                    <div className="text-4xl font-bold tabular-nums">{Number(sqc.risk_score ?? 0)}</div>
                    <div className="text-[10px] uppercase tracking-wide text-muted-foreground">out of 100</div>
                  </div>
                  <Badge
                    variant="outline"
                    className={cn("border px-3 py-1 text-sm", CATEGORY_TONE[sqc.risk_category ?? ""] ?? "")}
                  >
                    {sqc.risk_category}
                  </Badge>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {sqc.narrative ? (
                <p className="rounded-md border bg-muted/30 p-3 text-sm leading-relaxed">{sqc.narrative}</p>
              ) : null}
            </CardContent>
          </Card>

          <div className="grid gap-4 lg:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Component scores</CardTitle>
                <CardDescription>Contribution by signal category</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                {Object.keys(components).length === 0 ? (
                  <p className="text-sm text-muted-foreground">No component breakdown.</p>
                ) : (
                  Object.entries(components).map(([k, v]) => (
                    <div key={k}>
                      <div className="mb-1 flex items-center justify-between text-xs">
                        <span className="capitalize">{k.replace(/_/g, " ")}</span>
                        <span className="font-mono tabular-nums">{Number(v)}</span>
                      </div>
                      <Progress value={Math.min(100, Number(v))} className="h-2" />
                    </div>
                  ))
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">Key findings</CardTitle>
                <CardDescription>{findings.length} signals</CardDescription>
              </CardHeader>
              <CardContent>
                {findings.length === 0 ? (
                  <p className="text-sm text-muted-foreground">No findings.</p>
                ) : (
                  <ul className="space-y-2 text-sm">
                    {findings.map((f, i) => (
                      <li key={i} className="flex gap-2">
                        <span className="text-muted-foreground">·</span>
                        <span>{f}</span>
                      </li>
                    ))}
                  </ul>
                )}
              </CardContent>
            </Card>
          </div>

          {questions.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-base">
                  <HelpCircle className="h-4 w-4 text-primary" />
                  Proactive investigation questions
                </CardTitle>
                <CardDescription>{questions.length} suggested follow-ups</CardDescription>
              </CardHeader>
              <CardContent className="space-y-2">
                {questions.map((q) => (
                  <div key={q.id} className="rounded border p-3">
                    <div className="flex items-start justify-between gap-2">
                      <p className="text-sm font-medium">{q.question}</p>
                      <Badge variant="outline" className="shrink-0 capitalize">
                        {q.priority}
                      </Badge>
                    </div>
                    {q.target ? (
                      <div className="mt-1 text-[10px] text-muted-foreground">
                        Target: <span className="font-mono">{q.target}</span>
                      </div>
                    ) : null}
                    {q.rationale ? (
                      <p className="mt-1 text-xs italic text-muted-foreground">{q.rationale}</p>
                    ) : null}
                  </div>
                ))}
              </CardContent>
            </Card>
          )}
        </>
      )}
    </div>
  );
}
