import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { createServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ArrowRight, FileText, Upload, PlayCircle } from "lucide-react";

const listDemoClaims = createServerFn({ method: "GET" }).handler(async () => {
  const sb = supabaseAdmin;
  const { data } = await sb
    .from("claims")
    .select("*")
    .eq("is_demo", true)
    .order("claim_id");
  return { claims: data ?? [] };
});

export const Route = createFileRoute("/claims/new")({
  component: NewClaimPage,
});

const SCENARIO_META: Record<
  string,
  { title: string; expected: string; tone: "muted" | "warning" | "danger" }
> = {
  low_risk: {
    title: "Low Risk OD",
    expected: "DESKTOP_REVIEW · Risk ≈ Low",
    tone: "muted",
  },
  close_proximity_high_value: {
    title: "Close Proximity · High Value",
    expected: "FIELD_INVESTIGATION · Risk ≈ High",
    tone: "danger",
  },
  timeline_contradiction: {
    title: "Timeline Contradiction",
    expected: "FIELD_INVESTIGATION · Risk ≈ High",
    tone: "danger",
  },
  entity_mismatch: {
    title: "Entity Mismatch",
    expected: "DESKTOP_INVESTIGATION · Risk ≈ Medium",
    tone: "warning",
  },
};

function NewClaimPage() {
  const fetcher = useServerFn(listDemoClaims);
  const { data, isLoading } = useQuery({
    queryKey: ["demo-claims"],
    queryFn: () => fetcher(),
  });

  return (
    <div className="mx-auto w-full max-w-7xl space-y-6 p-6">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">
          Start an Investigation
        </h1>
        <p className="text-sm text-muted-foreground">
          Pick a seeded demo claim to run end-to-end, or upload your own documents.
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        {isLoading && (
          <p className="text-sm text-muted-foreground">Loading demo claims…</p>
        )}
        {data?.claims.map((c) => {
          const meta =
            SCENARIO_META[c.demo_scenario ?? ""] ??
            { title: c.demo_scenario ?? "Demo", expected: "—", tone: "muted" as const };
          return (
            <Card key={c.id} className="transition-colors hover:border-primary/60">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-base">{meta.title}</CardTitle>
                  <Badge
                    variant={
                      meta.tone === "danger"
                        ? "destructive"
                        : meta.tone === "warning"
                          ? "secondary"
                          : "outline"
                    }
                    className="text-[10px]"
                  >
                    {meta.expected}
                  </Badge>
                </div>
                <CardDescription className="font-mono text-xs">
                  {c.claim_id} · Policy {c.policy_number}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <Detail label="Claim Amount" value={`₹${Number(c.claim_amount ?? 0).toLocaleString("en-IN")}`} />
                  <Detail label="Incident Date" value={c.incident_date ?? "—"} />
                  <Detail label="Vehicle" value={c.vehicle_registration_number ?? "—"} />
                  <Detail label="Driver" value={c.driver_name ?? "—"} />
                </div>
                <div className="flex items-center justify-between border-t pt-3">
                  <span className="flex items-center gap-1 text-xs text-muted-foreground">
                    <FileText className="h-3 w-3" />
                    6 documents seeded
                  </span>
                  <Button asChild size="sm">
                    <Link to="/jobs/$jobId" params={{ jobId: c.id }}>
                      <PlayCircle className="h-3 w-3" />
                      Open & Run
                      <ArrowRight className="h-3 w-3" />
                    </Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <Card className="border-dashed">
        <CardHeader>
          <CardTitle className="text-base">Upload Your Own Documents</CardTitle>
          <CardDescription>
            Drag-and-drop PDFs (claim form, policy copy, RC, DL, FIR, estimate…) to start a fresh investigation.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col items-center justify-center gap-2 rounded border-2 border-dashed py-12 text-sm text-muted-foreground">
            <Upload className="h-6 w-6" />
            <span>Upload flow ships in a later build step.</span>
            <span className="text-xs">Use a demo claim above for the live run.</span>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function Detail({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <div className="text-[10px] uppercase tracking-wide text-muted-foreground">
        {label}
      </div>
      <div className="font-medium">{value}</div>
    </div>
  );
}
