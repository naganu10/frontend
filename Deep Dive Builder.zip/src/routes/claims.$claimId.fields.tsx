import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { getExtractedFields } from "@/lib/claim-detail.functions";
import { ClaimSubnav } from "@/components/claim-subnav";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { ArrowLeft, PlayCircle } from "lucide-react";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/claims/$claimId/fields")({
  component: FieldsPage,
});

function FieldsPage() {
  const { claimId } = Route.useParams();
  const fetcher = useServerFn(getExtractedFields);
  const { data, isLoading } = useQuery({
    queryKey: ["extracted-fields", claimId],
    queryFn: () => fetcher({ data: { claimId } }),
  });

  const fields = data?.fields ?? [];

  return (
    <div className="mx-auto w-full max-w-7xl space-y-6 p-6">
      <div>
        <Button asChild variant="ghost" size="sm" className="-ml-2 mb-2">
          <Link to="/jobs/$jobId" params={{ jobId: claimId }}>
            <ArrowLeft className="h-3 w-3" />
            Back to Execution Console
          </Link>
        </Button>
        <h1 className="text-2xl font-semibold tracking-tight">
          {isLoading ? "Loading…" : data?.claim?.claim_id}
        </h1>
        <p className="text-sm text-muted-foreground">Extracted Fields</p>
      </div>

      <ClaimSubnav claimId={claimId} active="fields" />

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Field Extraction</CardTitle>
          <CardDescription>
            {fields.length} fields extracted from claim documents
          </CardDescription>
        </CardHeader>
        <CardContent>
          {fields.length === 0 ? (
            <div className="flex flex-col items-center justify-center gap-3 py-12 text-center">
              <p className="text-sm text-muted-foreground">
                No extracted fields yet. Run the investigation pipeline first.
              </p>
              <Button asChild size="sm">
                <Link to="/jobs/$jobId" params={{ jobId: claimId }}>
                  <PlayCircle className="h-3 w-3" />
                  Go to Execution Console
                </Link>
              </Button>
            </div>
          ) : (
            <div className="overflow-hidden rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Document</TableHead>
                    <TableHead>Field Name</TableHead>
                    <TableHead>Raw Value</TableHead>
                    <TableHead>Normalized Value</TableHead>
                    <TableHead className="w-[180px]">Confidence</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {fields.map((f) => (
                    <TableRow key={f.id}>
                      <TableCell>
                        <Badge variant="outline" className="text-[10px]">
                          {f.document_type}
                        </Badge>
                      </TableCell>
                      <TableCell className="font-mono text-xs">
                        {f.field_name}
                      </TableCell>
                      <TableCell className="text-xs text-muted-foreground">
                        {f.raw_value ?? "—"}
                      </TableCell>
                      <TableCell className="text-xs font-medium">
                        {f.normalized_value ?? "—"}
                      </TableCell>
                      <TableCell>
                        <ConfidenceBar value={Number(f.confidence ?? 0)} />
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>

            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function ConfidenceBar({ value }: { value: number }) {
  const pct = Math.round(value * 100);
  const tone =
    value >= 0.85
      ? "bg-primary"
      : value >= 0.6
        ? "bg-amber-500"
        : "bg-destructive";
  return (
    <div className="flex items-center gap-2">
      <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-muted">
        <div
          className={cn("h-full transition-all", tone)}
          style={{ width: `${pct}%` }}
        />
      </div>
      <span className="w-9 text-right font-mono text-[10px] text-muted-foreground">
        {pct}%
      </span>
    </div>
  );
}
