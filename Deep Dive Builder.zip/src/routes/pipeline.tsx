import { createFileRoute } from "@tanstack/react-router";
import { ComingSoon } from "@/components/coming-soon";

export const Route = createFileRoute("/pipeline")({
  component: () => (
    <ComingSoon
      title="Pipeline Overview"
      description="Visual map of the 6-phase pipeline: Ingestion → Analysis → Entity → Scoring → Persistence → Callback."
    />
  ),
});
