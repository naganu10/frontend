import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  FileText,
  ListChecks,
  History,
  ArrowRight,
  PlayCircle,
} from "lucide-react";
import { getDashboardStats } from "@/lib/dashboard.functions";

export const Route = createFileRoute("/")({
  component: DashboardPage,
});

const SCENARIO_LABEL: Record<string, string> = {
  low_risk: "Low Risk OD",
  close_proximity_high_value: "Close Proximity · High Value",
  timeline_contradiction: "Timeline Contradiction",
  entity_mismatch: "Entity Mismatch",
};

function StatCard({
  label,
  value,
  icon: Icon,
  hint,
}: {
  label: string;
  value: number | string;
  icon: React.ComponentType<{ className?: string }>;
  hint?: string;
}) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-xs font-medium text-muted-foreground">
          {label}
        </CardTitle>
        <Icon className="h-4 w-4 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-semibold tracking-tight">{value}</div>
        {hint && (
          <p className="mt-1 text-xs text-muted-foreground">{hint}</p>
        )}
      </CardContent>
    </Card>
  );
}

function DashboardPage() {
  const fetchStats = useServerFn(getDashboardStats);
  const { data, isLoading } = useQuery({
    queryKey: ["dashboard-stats"],
    queryFn: () => fetchStats(),
  });

  return (
    <div className="mx-auto w-full max-w-7xl space-y-6 p-6">
      <div className="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">
            Claims Investigation Workbench
          </h1>
          <p className="text-sm text-muted-foreground">
            Agentic intake and triage for motor OD claims — Ingestion through Callback.
          </p>
        </div>
        <div className="flex gap-2">
          <Button asChild variant="outline">
            <Link to="/pipeline">
              View Pipeline
              <ArrowRight className="h-4 w-4" />
            </Link>
          </Button>
          <Button asChild>
            <Link to="/claims/new">
              <PlayCircle className="h-4 w-4" />
              Start Investigation
            </Link>
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
        <StatCard
          label="Claims"
          value={isLoading ? "—" : data?.claims.length ?? 0}
          icon={FileText}
          hint="Demo + uploaded"
        />
        <StatCard
          label="Master Rules"
          value={isLoading ? "—" : data?.counts.rules ?? 0}
          icon={ListChecks}
        />
        <StatCard
          label="Historical Claims"
          value={isLoading ? "—" : data?.counts.historical ?? 0}
          icon={History}
        />
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-base">Demo Claims</CardTitle>
            <CardDescription>
              Pre-seeded scenarios — open any to run the pipeline.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-2">
            {isLoading && (
              <p className="text-sm text-muted-foreground">Loading…</p>
            )}
            {data?.claims.map((c) => {
              const sqc = data.sqc.find((s) => s.claim_id === c.id);
              return (
                <div
                  key={c.id}
                  className="flex items-center justify-between rounded-md border p-3 hover:bg-accent/40 transition-colors"
                >
                  <div className="flex flex-col">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-sm font-medium">
                        {c.claim_id}
                      </span>
                      <Badge variant="outline" className="text-[10px]">
                        {SCENARIO_LABEL[c.demo_scenario ?? ""] ??
                          c.demo_scenario ??
                          "—"}
                      </Badge>
                      {sqc?.recommended_action && (
                        <Badge className="text-[10px]" variant="secondary">
                          {sqc.recommended_action}
                        </Badge>
                      )}
                    </div>
                    <span className="text-xs text-muted-foreground">
                      ₹{Number(c.claim_amount ?? 0).toLocaleString("en-IN")} ·{" "}
                      {c.status}
                    </span>
                  </div>
                  <Button asChild size="sm" variant="ghost">
                    <Link
                      to="/jobs/$jobId"
                      params={{ jobId: c.id }}
                    >
                      Open
                      <ArrowRight className="h-3 w-3" />
                    </Link>
                  </Button>
                </div>
              );
            })}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Recent Activity</CardTitle>
            <CardDescription>Latest job events</CardDescription>
          </CardHeader>
          <CardContent className="space-y-2">
            {data?.recentEvents.length === 0 && (
              <p className="text-sm text-muted-foreground">
                No pipeline runs yet. Start one from a demo claim.
              </p>
            )}
            {data?.recentEvents.map((e) => (
              <div key={e.id} className="border-l-2 border-muted pl-3">
                <div className="flex items-center gap-2 text-xs">
                  <Badge variant="outline" className="text-[10px]">
                    {e.phase}
                  </Badge>
                  <span className="text-muted-foreground">{e.status}</span>
                </div>
                <p className="text-xs text-foreground">{e.message}</p>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
