import { createFileRoute } from "@tanstack/react-router";
import { ComingSoon } from "@/components/coming-soon";

export const Route = createFileRoute("/skills")({
  component: () => (
    <ComingSoon
      title="Skills Library"
      description="10 cognitive skills — instruction text injected as LLM system prompts in AI Mode."
    />
  ),
});
