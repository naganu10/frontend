import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { getClaimDocuments } from "@/lib/claim-detail.functions";
import { ClaimSubnav } from "@/components/claim-subnav";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ArrowLeft, FileText, ExternalLink, CheckCircle2, Circle } from "lucide-react";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/claims/$claimId/documents")({
  component: DocumentsPage,
});

function DocumentsPage() {
  const { claimId } = Route.useParams();
  const fetcher = useServerFn(getClaimDocuments);
  const { data, isLoading } = useQuery({
    queryKey: ["claim-documents", claimId],
    queryFn: () => fetcher({ data: { claimId } }),
  });
  const [selectedId, setSelectedId] = useState<string | null>(null);

  const docs = data?.documents ?? [];
  const selected = docs.find((d) => d.id === selectedId) ?? docs[0] ?? null;
  const extractedDone = data?.hasExtractedFields ?? false;

  return (
    <div className="mx-auto w-full max-w-7xl space-y-6 p-6">
      <div>
        <Button asChild variant="ghost" size="sm" className="-ml-2 mb-2">
          <Link to="/jobs/$jobId" params={{ jobId: claimId }}>
            <ArrowLeft className="h-3 w-3" />
            Back to Execution Console
          </Link>
        </Button>
        <h1 className="text-2xl font-semibold tracking-tight">
          {isLoading ? "Loading…" : data?.claim?.claim_id}
        </h1>
        <p className="text-sm text-muted-foreground">Document Processing</p>
      </div>

      <ClaimSubnav claimId={claimId} active="documents" />

      <div className="grid gap-6 md:grid-cols-[320px_1fr]">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Uploaded Documents</CardTitle>
            <CardDescription>{docs.length} files</CardDescription>
          </CardHeader>
          <CardContent className="space-y-1.5">
            {docs.map((d) => {
              const isSel = (selected?.id ?? null) === d.id;
              return (
                <button
                  key={d.id}
                  onClick={() => setSelectedId(d.id)}
                  className={cn(
                    "flex w-full items-start gap-2 rounded-md border p-2 text-left text-xs transition-colors",
                    isSel
                      ? "border-primary bg-primary/5"
                      : "hover:border-primary/40 hover:bg-muted/40",
                  )}
                >
                  <FileText className="mt-0.5 h-3.5 w-3.5 shrink-0 text-muted-foreground" />
                  <div className="min-w-0 flex-1">
                    <div className="truncate font-medium">{d.file_name}</div>
                    <div className="mt-0.5 flex items-center gap-1.5">
                      <Badge variant="outline" className="text-[9px]">
                        {d.document_type}
                      </Badge>
                      <span className="text-[10px] text-muted-foreground">
                        {(d.detected_language ?? "en").toUpperCase()}
                      </span>
                    </div>
                  </div>
                </button>
              );
            })}
            {!isLoading && docs.length === 0 && (
              <p className="py-6 text-center text-xs text-muted-foreground">
                No documents uploaded.
              </p>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">
              {selected?.file_name ?? "Select a document"}
            </CardTitle>
            <CardDescription>
              {selected?.document_type ?? "—"} ·{" "}
              {selected ? `Confidence ${Math.round(Number(selected.classification_confidence ?? 0) * 100)}%` : ""}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-5">
            {selected ? (
              <>
                <div className="flex items-center gap-3">
                  <StatusPill done label="Uploaded" />
                  <StatusPill done label="Classified" />
                  <StatusPill done={extractedDone} label="Extracted" />
                </div>

                <div className="grid grid-cols-2 gap-3 text-sm">
                  <Field label="Document Type" value={selected.document_type} />
                  <Field
                    label="Language"
                    value={(selected.detected_language ?? "en").toUpperCase()}
                  />
                  <Field
                    label="Translation Required"
                    value={selected.translation_required ? "Yes" : "No"}
                  />
                  <Field label="Status" value={selected.status} />
                  <Field
                    label="Extracted Fields (Claim)"
                    value={String(data?.extractedFieldCount ?? 0)}
                  />
                  <Field
                    label="Storage Path"
                    value={selected.storage_path ?? "—"}
                    mono
                  />
                </div>

                <div>
                  <div className="mb-2 text-[10px] uppercase tracking-wide text-muted-foreground">
                    OCR Snippet
                  </div>
                  <div className="rounded-md border bg-muted/40 p-3 font-mono text-xs leading-relaxed text-muted-foreground">
                    {selected.extracted_text?.trim()
                      ? selected.extracted_text.slice(0, 600)
                      : "[Demo Mode] OCR text will appear here once the pipeline ingests this PDF. In Demo Mode, fields are seeded directly from the scenario engine."}
                  </div>
                </div>

                {selected.signed_url && (
                  <Button asChild variant="outline" size="sm">
                    <a
                      href={selected.signed_url}
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <ExternalLink className="h-3 w-3" />
                      Open PDF
                    </a>
                  </Button>
                )}
              </>
            ) : (
              <p className="py-6 text-sm text-muted-foreground">
                Select a document on the left to view details.
              </p>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function StatusPill({ done, label }: { done: boolean; label: string }) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[11px]",
        done
          ? "border-primary/40 bg-primary/5 text-foreground"
          : "border-muted text-muted-foreground",
      )}
    >
      {done ? (
        <CheckCircle2 className="h-3 w-3 text-primary" />
      ) : (
        <Circle className="h-3 w-3" />
      )}
      {label}
    </span>
  );
}

function Field({
  label,
  value,
  mono,
}: {
  label: string;
  value?: string | null;
  mono?: boolean;
}) {
  return (
    <div>
      <div className="text-[10px] uppercase tracking-wide text-muted-foreground">
        {label}
      </div>
      <div className={cn("font-medium break-words", mono && "font-mono text-xs")}>
        {value ?? "—"}
      </div>
    </div>
  );
}
