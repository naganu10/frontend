import { createFileRoute } from "@tanstack/react-router";
import { ComingSoon } from "@/components/coming-soon";

export const Route = createFileRoute("/tools")({
  component: () => (
    <ComingSoon
      title="Tools Registry"
      description="13 deterministic tools that skills invoke during pipeline execution."
    />
  ),
});
