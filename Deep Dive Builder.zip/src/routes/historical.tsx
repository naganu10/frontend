import { createFileRoute } from "@tanstack/react-router";
import { ComingSoon } from "@/components/coming-soon";

export const Route = createFileRoute("/historical")({
  component: () => (
    <ComingSoon
      title="Historical Claims"
      description="30 fabricated historical claims used for entity matching and pattern detection."
    />
  ),
});
