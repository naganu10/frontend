import { createFileRoute } from "@tanstack/react-router";
import { ComingSoon } from "@/components/coming-soon";

export const Route = createFileRoute("/admin")({
  component: () => (
    <ComingSoon
      title="Admin"
      description="Demo/AI mode toggle, rule editing, rules source toggle, Gemini API key status."
    />
  ),
});
