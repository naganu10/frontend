import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { createServerFn } from "@tanstack/react-start";
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  FileText,
  ArrowLeft,
  PlayCircle,
  CheckCircle2,
  Loader2,
  Circle,
  Bot,
  Sparkles,
  Wrench,
} from "lucide-react";
import { startPipeline, getJobEvents } from "@/lib/pipeline.functions";
import { ClaimSubnav } from "@/components/claim-subnav";
import { cn } from "@/lib/utils";

const getClaim = createServerFn({ method: "GET" })
  .inputValidator((d: { id: string }) => d)
  .handler(async ({ data }) => {
    const sb = supabaseAdmin;
    const [claim, docs] = await Promise.all([
      sb.from("claims").select("*").eq("id", data.id).maybeSingle(),
      sb.from("claim_documents").select("*").eq("claim_id", data.id),
    ]);
    return { claim: claim.data, documents: docs.data ?? [] };
  });

export const Route = createFileRoute("/jobs/$jobId")({
  component: JobPage,
});

const PHASES = [
  "Ingestion",
  "Analysis",
  "Entity",
  "Scoring",
  "Persistence",
  "Callback",
] as const;

function JobPage() {
  const { jobId } = Route.useParams();
  const fetchClaim = useServerFn(getClaim);
  const fetchEvents = useServerFn(getJobEvents);
  const runPipeline = useServerFn(startPipeline);
  const qc = useQueryClient();

  const { data, isLoading } = useQuery({
    queryKey: ["job", jobId],
    queryFn: () => fetchClaim({ data: { id: jobId } }),
  });

  const mutation = useMutation({
    mutationKey: ["run-pipeline", jobId],
    mutationFn: () => runPipeline({ data: { claimId: jobId } }),
    onMutate: () => {
      // Optimistically clear so the UI doesn't show old completed run.
      qc.setQueryData(["job-events", jobId], { events: [], sqc: null });
      invalidateAll();
    },
    onSuccess: () => invalidateAll(),
    onSettled: () => invalidateAll(),
  });

  function invalidateAll() {
    for (const key of [
      ["job-events", jobId],
      ["job", jobId],
      ["extracted-fields", jobId],
      ["extracted-facts", jobId],
      ["triggered-rules", jobId],
      ["contradictions", jobId],
      ["claim-documents", jobId],
      ["claim-entities", jobId],
      ["claim-score", jobId],
      ["claim-final-payload", jobId],
    ]) {
      qc.invalidateQueries({ queryKey: key });
    }
  }

  const events = useQuery({
    queryKey: ["job-events", jobId],
    queryFn: () => fetchEvents({ data: { claimId: jobId } }),
    refetchInterval: (q) => {
      // Keep polling while the mutation is in flight (server is emitting events).
      if (mutation.isPending) return 1000;
      const ev = q.state.data?.events ?? [];
      const last = ev[ev.length - 1];
      const done =
        last &&
        last.phase === "Callback" &&
        last.status === "completed" &&
        last.tool_used === "callback.prepare";
      return done ? false : 1000;
    },
  });

  const evList = events.data?.events ?? [];
  const sqc = events.data?.sqc ?? null;
  const phaseStatus = computePhaseStatus(evList);
  const isRunning =
    mutation.isPending || (evList.length > 0 && !phaseStatus.Callback?.done);

  return (
    <div className="mx-auto w-full max-w-7xl space-y-6 p-6">
      <div className="flex items-center justify-between gap-4">
        <div>
          <Button asChild variant="ghost" size="sm" className="-ml-2 mb-2">
            <Link to="/">
              <ArrowLeft className="h-3 w-3" />
              Back to Dashboard
            </Link>
          </Button>
          <h1 className="text-2xl font-semibold tracking-tight">
            {isLoading ? "Loading…" : data?.claim?.claim_id}
          </h1>
          <p className="text-sm text-muted-foreground">
            {data?.claim?.demo_scenario ?? "Investigation job"}
          </p>
        </div>
        <div className="flex items-center gap-2">
          {sqc && (
            <Badge variant="secondary" className="text-xs">
              {sqc.recommended_action} · Risk {sqc.risk_score}
            </Badge>
          )}
          <Button
            onClick={() => mutation.mutate()}
            disabled={mutation.isPending || isRunning}
          >
            {isRunning ? (
              <>
                <Loader2 className="h-3 w-3 animate-spin" />
                Running…
              </>
            ) : (
              <>
                <PlayCircle className="h-3 w-3" />
                {evList.length ? "Re-run Investigation" : "Run Investigation"}
              </>
            )}
          </Button>
        </div>
      </div>

      <ClaimSubnav claimId={jobId} active="timeline" />

      <div className="grid gap-6 md:grid-cols-3">
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle className="text-base">Claim Summary</CardTitle>
          </CardHeader>
          <CardContent className="grid grid-cols-2 gap-3 text-sm">
            {data?.claim && (
              <>
                <Field label="Policy" value={data.claim.policy_number} />
                <Field
                  label="Claim Amount"
                  value={`₹${Number(data.claim.claim_amount ?? 0).toLocaleString("en-IN")}`}
                />
                <Field label="Incident Date" value={data.claim.incident_date} />
                <Field label="Vehicle" value={data.claim.vehicle_registration_number} />
                <Field label="Insured" value={data.claim.insured_name} />
                <Field label="Driver" value={data.claim.driver_name} />
                <Field label="Garage" value={data.claim.garage_name} />
                <Field label="Location" value={data.claim.incident_location} />
              </>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Documents</CardTitle>
            <CardDescription>
              {data?.documents.length ?? 0} files in storage
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-2">
            {data?.documents.map((d) => (
              <div
                key={d.id}
                className="flex items-center gap-2 rounded border p-2 text-xs"
              >
                <FileText className="h-3 w-3 text-muted-foreground" />
                <span className="flex-1 truncate">{d.file_name}</span>
                <Badge variant="outline" className="text-[10px]">
                  {d.document_type}
                </Badge>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Execution Console</CardTitle>
          <CardDescription>
            6-phase agentic pipeline · Agent / Skill / Tool separation
          </CardDescription>
        </CardHeader>
        <CardContent className="grid gap-6 md:grid-cols-[280px_1fr]">
          {/* Phase timeline */}
          <div className="space-y-2">
            {PHASES.map((phase, i) => {
              const s = phaseStatus[phase];
              const state = !s
                ? "pending"
                : s.done
                  ? "done"
                  : "running";
              return (
                <div
                  key={phase}
                  className={cn(
                    "flex items-center gap-3 rounded-md border p-3",
                    state === "done" && "border-primary/40 bg-primary/5",
                    state === "running" && "border-primary bg-primary/10",
                  )}
                >
                  <PhaseIcon state={state} />
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-medium text-muted-foreground">
                        Phase {i + 1}
                      </span>
                    </div>
                    <div className="text-sm font-semibold">{phase}</div>
                    {s && (
                      <div className="text-[11px] text-muted-foreground">
                        {s.completed}/{s.total} steps
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Activity log */}
          <div>
            <div className="mb-2 flex items-center justify-between">
              <span className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                Activity Log
              </span>
              <div className="flex gap-2 text-[10px]">
                <LegendDot color="bg-blue-500" label="Agent" icon={Bot} />
                <LegendDot color="bg-purple-500" label="Skill" icon={Sparkles} />
                <LegendDot color="bg-amber-500" label="Tool" icon={Wrench} />
              </div>
            </div>
            <ScrollArea className="h-[460px] rounded-md border">
              <div className="p-3">
                {evList.length === 0 && (
                  <div className="py-10 text-center text-sm text-muted-foreground">
                    No runs yet. Click <strong>Run Investigation</strong> to start the agentic pipeline.
                  </div>
                )}
                {evList.map((e) => (
                  <LogRow key={e.id} event={e} />
                ))}
              </div>
            </ScrollArea>
          </div>
        </CardContent>
      </Card>

      {sqc && (
        <Card className="border-primary/40">
          <CardHeader>
            <CardTitle className="text-base">Result Snapshot</CardTitle>
            <CardDescription>Detailed views ship in the next build steps.</CardDescription>
          </CardHeader>
          <CardContent className="grid gap-4 md:grid-cols-4">
            <Field label="Risk Score" value={String(sqc.risk_score)} />
            <Field label="Risk Category" value={sqc.risk_category ?? "—"} />
            <Field label="Recommended Action" value={sqc.recommended_action ?? "—"} />
            <Field label="Findings" value={String((sqc.key_findings as unknown[] | null)?.length ?? 0)} />
            <div className="md:col-span-4 text-sm text-muted-foreground">
              {sqc.narrative}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

function computePhaseStatus(
  events: Array<{ phase: string | null; status: string }>,
) {
  const map: Record<string, { total: number; completed: number; done: boolean }> = {};
  for (const phase of PHASES) {
    const phaseEvents = events.filter((e) => e.phase === phase);
    const starts = phaseEvents.filter((e) => e.status === "started").length;
    const completes = phaseEvents.filter((e) => e.status === "completed").length;
    if (starts === 0) continue;
    map[phase] = {
      total: starts,
      completed: completes,
      done: completes >= starts && starts > 0,
    };
  }
  return map as Record<(typeof PHASES)[number], { total: number; completed: number; done: boolean } | undefined>;
}

function PhaseIcon({ state }: { state: "pending" | "running" | "done" }) {
  if (state === "done") return <CheckCircle2 className="h-5 w-5 text-primary" />;
  if (state === "running") return <Loader2 className="h-5 w-5 animate-spin text-primary" />;
  return <Circle className="h-5 w-5 text-muted-foreground/40" />;
}

function LegendDot({
  color,
  label,
  icon: Icon,
}: {
  color: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
}) {
  return (
    <span className="inline-flex items-center gap-1 rounded-full border px-2 py-0.5">
      <Icon className="h-2.5 w-2.5" />
      <span className={cn("h-1.5 w-1.5 rounded-full", color)} />
      {label}
    </span>
  );
}

function LogRow({
  event,
}: {
  event: {
    id: string;
    phase: string | null;
    agent_name: string | null;
    skill_applied: string | null;
    tool_used: string | null;
    status: string;
    message: string | null;
    payload: unknown;
    created_at: string;
  };
}) {
  const isCompleted = event.status === "completed";
  const time = new Date(event.created_at).toLocaleTimeString();
  return (
    <div
      className={cn(
        "border-l-2 py-2 pl-3 text-xs",
        isCompleted ? "border-primary/40" : "border-muted",
      )}
    >
      <div className="flex flex-wrap items-center gap-1.5">
        <span className="font-mono text-[10px] text-muted-foreground">{time}</span>
        <Badge variant="outline" className="h-4 text-[9px]">{event.phase}</Badge>
        <Chip color="bg-blue-500/15 text-blue-700 dark:text-blue-300" icon={Bot}>
          {event.agent_name}
        </Chip>
        <Chip color="bg-purple-500/15 text-purple-700 dark:text-purple-300" icon={Sparkles}>
          {event.skill_applied}
        </Chip>
        <Chip color="bg-amber-500/15 text-amber-700 dark:text-amber-300" icon={Wrench}>
          {event.tool_used}
        </Chip>
        <span className="ml-auto text-[10px] text-muted-foreground">
          {isCompleted ? "✓ completed" : "▶ started"}
        </span>
      </div>
      <div className="mt-1 text-foreground">{event.message}</div>
      {isCompleted && event.payload && Object.keys(event.payload as object).length > 0 ? (
        <div className="mt-1 font-mono text-[10px] text-muted-foreground">
          {JSON.stringify(event.payload)}
        </div>
      ) : null}

    </div>
  );
}

function Chip({
  children,
  color,
  icon: Icon,
}: {
  children: string | null;
  color: string;
  icon: React.ComponentType<{ className?: string }>;
}) {
  if (!children) return null;
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded px-1.5 py-0.5 text-[10px] font-medium",
        color,
      )}
    >
      <Icon className="h-2.5 w-2.5" />
      {children}
    </span>
  );
}


function Field({ label, value }: { label: string; value?: string | null }) {
  return (
    <div>
      <div className="text-[10px] uppercase tracking-wide text-muted-foreground">
        {label}
      </div>
      <div className="font-medium">{value ?? "—"}</div>
    </div>
  );
}
