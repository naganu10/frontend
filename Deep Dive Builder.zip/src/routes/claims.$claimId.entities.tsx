import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { getClaimEntities } from "@/lib/claim-detail.functions";
import { ClaimSubnav } from "@/components/claim-subnav";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Network, AlertTriangle, History } from "lucide-react";

export const Route = createFileRoute("/claims/$claimId/entities")({
  component: EntitiesPage,
});

function EntitiesPage() {
  const { claimId } = Route.useParams();
  const fetcher = useServerFn(getClaimEntities);
  const { data, isLoading } = useQuery({
    queryKey: ["claim-entities", claimId],
    queryFn: () => fetcher({ data: { claimId } }),
  });

  const resolved = data?.resolved ?? [];

  return (
    <div className="mx-auto w-full max-w-7xl space-y-6 p-6">
      <div>
        <Button asChild variant="ghost" size="sm" className="-ml-2 mb-2">
          <Link to="/jobs/$jobId" params={{ jobId: claimId }}>
            <ArrowLeft className="h-3 w-3" />
            Back to Execution Console
          </Link>
        </Button>
        <h1 className="text-2xl font-semibold tracking-tight">
          {isLoading ? "Loading…" : data?.claim?.claim_id}
        </h1>
        <p className="text-sm text-muted-foreground">Entity Graph</p>
      </div>

      <ClaimSubnav claimId={claimId} active="entities" />

      {resolved.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center text-sm text-muted-foreground">
            No resolved entities yet. Run the pipeline to extract and resolve entities.
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 lg:grid-cols-2">
          {resolved.map((re) => (
            <Card key={re.id}>
              <CardHeader>
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <CardTitle className="flex items-center gap-2 text-base">
                      <Network className="h-4 w-4 text-primary" />
                      {re.canonical_value}
                    </CardTitle>
                    <CardDescription className="mt-1 flex items-center gap-2">
                      <Badge variant="secondary" className="capitalize">{re.entity_type}</Badge>
                      <span className="font-mono text-[10px]">{re.resolution_method}</span>
                      <span className="font-mono text-[10px]">{Math.round(Number(re.confidence ?? 0) * 100)}%</span>
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <p className="mb-2 text-xs font-medium uppercase tracking-wide text-muted-foreground">
                    Raw mentions ({re.mentions.length})
                  </p>
                  <div className="space-y-1.5">
                    {re.mentions.map((m) => (
                      <div key={m.id} className="flex items-start justify-between gap-2 rounded border bg-muted/30 px-2 py-1.5 text-xs">
                        <div>
                          <div className="font-medium">{m.raw_mention}</div>
                          <div className="text-[10px] text-muted-foreground">{m.label}</div>
                        </div>
                        <span className="rounded border bg-background px-1.5 py-0.5 font-mono text-[10px]">
                          {m.document_type}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <p className="mb-2 flex items-center gap-1.5 text-xs font-medium uppercase tracking-wide text-muted-foreground">
                    <History className="h-3 w-3" />
                    Historical matches ({re.historical.length})
                  </p>
                  {re.historical.length === 0 ? (
                    <p className="text-xs text-muted-foreground">No prior claims matched.</p>
                  ) : (
                    <div className="space-y-1.5">
                      {re.historical.map((h, i) => (
                        <div
                          key={i}
                          className="flex items-start justify-between gap-2 rounded border px-2 py-1.5 text-xs"
                        >
                          <div className="space-y-0.5">
                            <div className="flex items-center gap-1.5 font-medium">
                              {h.suspicious_flag ? (
                                <AlertTriangle className="h-3 w-3 text-amber-500" />
                              ) : null}
                              {String(h.historical_claim_id ?? "")}
                            </div>
                            <div className="text-[10px] text-muted-foreground">
                              matched on <span className="font-mono">{String(h.match_field ?? "")}</span>
                              {h.incident_date ? ` · ${String(h.incident_date)}` : ""}
                              {h.investigation_outcome ? ` · ${String(h.investigation_outcome)}` : ""}
                            </div>
                            {h.pattern_notes ? (
                              <div className="text-[10px] italic text-muted-foreground">{String(h.pattern_notes)}</div>
                            ) : null}
                          </div>
                          <Badge
                            variant={h.suspicious_flag ? "destructive" : "secondary"}
                            className="shrink-0"
                          >
                            {String(h.risk_category ?? "")}
                          </Badge>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
