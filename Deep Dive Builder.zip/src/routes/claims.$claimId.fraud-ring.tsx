import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { getFraudRingPatterns } from "@/lib/claim-detail.functions";
import { ClaimSubnav } from "@/components/claim-subnav";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Users, ShieldCheck } from "lucide-react";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/claims/$claimId/fraud-ring")({
  component: FraudRingPage,
});

function severityTone(sev: string | null) {
  switch ((sev ?? "").toLowerCase()) {
    case "high":
      return "bg-destructive/15 text-destructive";
    case "medium":
      return "bg-amber-500/15 text-amber-700 dark:text-amber-300";
    case "low":
      return "bg-muted text-muted-foreground";
    default:
      return "bg-muted text-muted-foreground";
  }
}

function FraudRingPage() {
  const { claimId } = Route.useParams();
  const fetcher = useServerFn(getFraudRingPatterns);
  const { data, isLoading } = useQuery({
    queryKey: ["fraud-ring", claimId],
    queryFn: () => fetcher({ data: { claimId } }),
  });

  const patterns = data?.patterns ?? [];

  return (
    <div className="mx-auto w-full max-w-7xl space-y-6 p-6">
      <div>
        <Button asChild variant="ghost" size="sm" className="-ml-2 mb-2">
          <Link to="/jobs/$jobId" params={{ jobId: claimId }}>
            <ArrowLeft className="h-3 w-3" />
            Back to Execution Console
          </Link>
        </Button>
        <h1 className="text-2xl font-semibold tracking-tight">
          {isLoading ? "Loading…" : data?.claim?.claim_id}
        </h1>
        <p className="text-sm text-muted-foreground">Fraud Ring Patterns</p>
      </div>

      <ClaimSubnav claimId={claimId} active="fraud ring" />

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Detected patterns</CardTitle>
          <CardDescription>
            Recurring entity clusters across this claim and historical claims
          </CardDescription>
        </CardHeader>
        <CardContent>
          {patterns.length === 0 ? (
            <div className="flex flex-col items-center justify-center gap-3 py-12 text-center">
              <ShieldCheck className="h-8 w-8 text-emerald-500" />
              <p className="text-sm text-muted-foreground">
                No fraud-ring patterns detected on this claim.
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {patterns.map((p) => {
                const shared = (p.shared_entities ?? []) as Array<{
                  id: string;
                  entity_type: string;
                  canonical_value: string;
                }>;
                const historical = (p.historical_claim_ids ?? []) as unknown as string[];
                return (
                  <div key={p.id} className="space-y-3 rounded-md border p-4">
                    <div className="flex flex-wrap items-start justify-between gap-2">
                      <div className="flex items-start gap-2">
                        <Users className="mt-0.5 h-4 w-4 shrink-0 text-muted-foreground" />
                        <div>
                          <div className="text-sm font-medium">{p.pattern_name}</div>
                          <div className="font-mono text-[11px] text-muted-foreground">{p.pattern_type}</div>
                        </div>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <span
                          className={cn(
                            "rounded px-1.5 py-0.5 text-[10px] font-medium uppercase tracking-wide",
                            severityTone(p.severity),
                          )}
                        >
                          {p.severity}
                        </span>
                        <span className="rounded bg-muted px-1.5 py-0.5 font-mono text-[10px] text-muted-foreground">
                          {Math.round(Number(p.confidence ?? 0) * 100)}%
                        </span>
                      </div>
                    </div>
                    {p.explanation && (
                      <p className="text-sm text-muted-foreground">{p.explanation}</p>
                    )}
                    <div className="grid gap-3 sm:grid-cols-2">
                      <div className="rounded border bg-muted/30 p-2.5">
                        <div className="mb-1 text-[10px] font-medium uppercase tracking-wide text-muted-foreground">
                          Shared entities ({shared.length})
                        </div>
                        <ul className="space-y-1 text-xs">
                          {shared.map((s) => (
                            <li key={s.id} className="flex items-center gap-2">
                              <span className="font-mono text-[10px] text-muted-foreground">{s.entity_type}</span>
                              <span>{s.canonical_value}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                      <div className="rounded border bg-muted/30 p-2.5">
                        <div className="mb-1 text-[10px] font-medium uppercase tracking-wide text-muted-foreground">
                          Historical claims ({historical.length})
                        </div>
                        <ul className="space-y-1 font-mono text-xs">
                          {historical.map((h) => (
                            <li key={h}>{h}</li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
