import { useState } from "react";
import { ChevronDown, ChevronRight, AlertTriangle, FileText, Lightbulb, Table } from "lucide-react";
import { cn } from "@/lib/utils";

const LOW_CONF = 0.75;

export interface EvidenceFact {
  id: string;
  fact_text: string;
  fact_type: string | null;
  confidence: number | null;
  document_type: string;
}
export interface EvidenceField {
  id: string;
  field_name: string;
  raw_value: string | null;
  normalized_value: string | null;
  confidence: number | null;
  document_type: string;
}
export interface EvidenceDoc {
  id: string;
  document_type: string;
  file_name: string | null;
}

export function VerifyChip({ confidence }: { confidence: number | null | undefined }) {
  const c = Number(confidence ?? 1);
  if (!confidence || c >= LOW_CONF) return null;
  return (
    <span className="inline-flex items-center gap-1 rounded bg-amber-500/15 px-1.5 py-0.5 text-[10px] font-medium uppercase tracking-wide text-amber-700 dark:text-amber-300">
      <AlertTriangle className="h-3 w-3" />
      Verify source · {Math.round(c * 100)}%
    </span>
  );
}

export function EvidenceTrail({
  facts,
  fields,
  documents,
  minConfidence,
}: {
  facts?: EvidenceFact[];
  fields?: EvidenceField[];
  documents?: EvidenceDoc[];
  minConfidence?: number | null;
}) {
  const [open, setOpen] = useState(false);
  const total = (facts?.length ?? 0) + (fields?.length ?? 0) + (documents?.length ?? 0);
  if (total === 0) return null;
  return (
    <div className="rounded border bg-muted/20">
      <button
        onClick={() => setOpen((v) => !v)}
        className="flex w-full items-center justify-between gap-2 px-2.5 py-1.5 text-[11px] hover:bg-muted/40"
      >
        <span className="flex items-center gap-1.5 font-medium">
          {open ? <ChevronDown className="h-3 w-3" /> : <ChevronRight className="h-3 w-3" />}
          Evidence ({total})
        </span>
        <VerifyChip confidence={minConfidence ?? null} />
      </button>
      {open && (
        <div className="space-y-2 border-t p-2.5">
          {documents && documents.length > 0 && (
            <Section icon={FileText} label="Documents">
              {documents.map((d) => (
                <li key={d.id} className="flex items-center gap-2">
                  <span className="font-mono text-[10px] text-muted-foreground">{d.document_type}</span>
                  <span className="truncate">{d.file_name ?? "—"}</span>
                </li>
              ))}
            </Section>
          )}
          {facts && facts.length > 0 && (
            <Section icon={Lightbulb} label="Facts">
              {facts.map((f) => (
                <li key={f.id} className="space-y-0.5">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-[10px] text-muted-foreground">{f.document_type}</span>
                    <VerifyChip confidence={f.confidence} />
                  </div>
                  <p className="text-[11px] leading-relaxed">{f.fact_text}</p>
                </li>
              ))}
            </Section>
          )}
          {fields && fields.length > 0 && (
            <Section icon={Table} label="Fields">
              {fields.map((f) => (
                <li key={f.id} className="flex flex-wrap items-center gap-2">
                  <span className="font-mono text-[10px] text-muted-foreground">{f.document_type}</span>
                  <span className="text-[11px] font-medium">{f.field_name}</span>
                  <span className="font-mono text-[11px]">{f.normalized_value ?? f.raw_value}</span>
                  <VerifyChip confidence={f.confidence} />
                </li>
              ))}
            </Section>
          )}
        </div>
      )}
    </div>
  );
}

function Section({
  icon: Icon,
  label,
  children,
}: {
  icon: typeof FileText;
  label: string;
  children: React.ReactNode;
}) {
  return (
    <div>
      <div className={cn("mb-1 flex items-center gap-1.5 text-[10px] font-medium uppercase tracking-wide text-muted-foreground")}>
        <Icon className="h-3 w-3" />
        {label}
      </div>
      <ul className="space-y-1.5 pl-1">{children}</ul>
    </div>
  );
}
