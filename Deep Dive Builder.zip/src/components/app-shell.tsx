import { Outlet, useRouterState, Link } from "@tanstack/react-router";
import {
  SidebarProvider,
  SidebarTrigger,
  SidebarInset,
} from "@/components/ui/sidebar";
import { AppSidebar } from "./app-sidebar";
import { Badge } from "@/components/ui/badge";

const ROUTE_LABELS: Record<string, string> = {
  "": "Dashboard",
  claims: "Claims",
  new: "New Investigation",
  jobs: "Job",
  rules: "Rules & Triggers",
  historical: "Historical Claims",
  skills: "Skills Library",
  tools: "Tools Registry",
  admin: "Admin",
  pipeline: "Pipeline Overview",
  documents: "Documents",
  fields: "Extracted Fields",
  facts: "Facts Board",
  contradictions: "Contradictions",
  entities: "Entity Graph",
  scoring: "Scoring",
  guidance: "Guidance",
  result: "Final Result",
};

function Breadcrumbs() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const parts = pathname.split("/").filter(Boolean);
  const crumbs = [{ label: "Home", to: "/" as const }];
  let acc = "";
  for (const p of parts) {
    acc += "/" + p;
    crumbs.push({ label: ROUTE_LABELS[p] ?? p, to: acc as never });
  }
  return (
    <nav className="flex items-center gap-1 text-xs text-muted-foreground">
      {crumbs.map((c, i) => (
        <span key={i} className="flex items-center gap-1">
          {i > 0 && <span className="opacity-50">/</span>}
          {i === crumbs.length - 1 ? (
            <span className="font-medium text-foreground">{c.label}</span>
          ) : (
            <Link to={c.to} className="hover:text-foreground transition-colors">
              {c.label}
            </Link>
          )}
        </span>
      ))}
    </nav>
  );
}

export function AppShell() {
  return (
    <SidebarProvider>
      <div className="flex min-h-screen w-full bg-background">
        <AppSidebar />
        <SidebarInset className="flex flex-1 flex-col">
          <header className="sticky top-0 z-10 flex h-14 items-center gap-3 border-b bg-background/95 px-4 backdrop-blur supports-[backdrop-filter]:bg-background/60">
            <SidebarTrigger />
            <div className="h-5 w-px bg-border" />
            <Breadcrumbs />
            <div className="ml-auto flex items-center gap-2">
              <Badge variant="outline" className="text-[10px] font-normal">
                Demo Mode
              </Badge>
              <Badge variant="secondary" className="text-[10px] font-normal">
                v1.0
              </Badge>
            </div>
          </header>
          <main className="flex-1 overflow-auto">
            <Outlet />
          </main>
        </SidebarInset>
      </div>
    </SidebarProvider>
  );
}
