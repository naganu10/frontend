import { Link, useParams } from "@tanstack/react-router";
import { cn } from "@/lib/utils";
import { Activity, FileText, Table, Lightbulb, ShieldAlert, GitCompare, Network, Users, HelpCircle, Gauge, Braces } from "lucide-react";

const TABS = [
  { to: "/jobs/$jobId", label: "Timeline", icon: Activity, exact: true },
  { to: "/claims/$claimId/documents", label: "Documents", icon: FileText, paramKey: "claimId" as const },
  { to: "/claims/$claimId/fields", label: "Fields", icon: Table, paramKey: "claimId" as const },
  { to: "/claims/$claimId/facts", label: "Facts", icon: Lightbulb, paramKey: "claimId" as const },
  { to: "/claims/$claimId/rules", label: "Rules", icon: ShieldAlert, paramKey: "claimId" as const },
  { to: "/claims/$claimId/contradictions", label: "Contradictions", icon: GitCompare, paramKey: "claimId" as const },
  { to: "/claims/$claimId/entities", label: "Entities", icon: Network, paramKey: "claimId" as const },
  { to: "/claims/$claimId/fraud-ring", label: "Fraud Ring", icon: Users, paramKey: "claimId" as const },
  { to: "/claims/$claimId/questions", label: "Questions", icon: HelpCircle, paramKey: "claimId" as const },
  { to: "/claims/$claimId/score", label: "Score", icon: Gauge, paramKey: "claimId" as const },
  { to: "/claims/$claimId/output", label: "Output", icon: Braces, paramKey: "claimId" as const },
];

export type ClaimSubnavActive =
  | "timeline"
  | "documents"
  | "fields"
  | "facts"
  | "rules"
  | "contradictions"
  | "entities"
  | "fraud ring"
  | "questions"
  | "score"
  | "output";

export function ClaimSubnav({ claimId, active }: { claimId: string; active: ClaimSubnavActive }) {
  return (
    <div className="flex items-center gap-1 overflow-x-auto border-b">
      {TABS.map((t) => {
        const key = t.label.toLowerCase();
        const isActive = key === active;
        const Icon = t.icon;
        const to = t.to;
        const params = t.paramKey
          ? { [t.paramKey]: claimId }
          : { jobId: claimId };
        return (
          <Link
            key={t.label}
            to={to}
            params={params as never}
            className={cn(
              "flex items-center gap-2 whitespace-nowrap border-b-2 px-3 py-2 text-sm transition-colors",
              isActive
                ? "border-primary text-foreground"
                : "border-transparent text-muted-foreground hover:text-foreground",
            )}
          >
            <Icon className="h-3.5 w-3.5" />
            {t.label}
          </Link>
        );
      })}
    </div>
  );
}

export function useClaimIdParam() {
  const params = useParams({ strict: false }) as { claimId?: string; jobId?: string };
  return params.claimId ?? params.jobId ?? "";
}
