import { createServerFn } from "@tanstack/react-start";
import { supabaseAdmin } from "@/integrations/supabase/client.server";

export const getDashboardStats = createServerFn({ method: "GET" }).handler(
  async () => {
    const sb = supabaseAdmin;
    const [claims, rules, hist, skills, tools, events, sqc] = await Promise.all(
      [
        sb.from("claims").select("id, status, claim_amount, demo_scenario, claim_id, created_at").order("created_at", { ascending: false }),
        sb.from("master_rules").select("id", { count: "exact", head: true }),
        sb.from("historical_claims").select("id", { count: "exact", head: true }),
        sb.from("skills").select("id", { count: "exact", head: true }),
        sb.from("tools_registry").select("id", { count: "exact", head: true }),
        sb.from("job_events").select("id, claim_id, phase, status, message, created_at").order("created_at", { ascending: false }).limit(10),
        sb.from("sqc_results").select("claim_id, risk_score, risk_category, recommended_action"),
      ],
    );

    return {
      claims: claims.data ?? [],
      counts: {
        rules: rules.count ?? 0,
        historical: hist.count ?? 0,
        skills: skills.count ?? 0,
        tools: tools.count ?? 0,
      },
      recentEvents: events.data ?? [],
      sqc: sqc.data ?? [],
    };
  },
);
