import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { supabaseAdmin } from "@/integrations/supabase/client.server";

const ClaimIdInput = z.object({ claimId: z.string().uuid() });

export const getClaimDocuments = createServerFn({ method: "GET" })
  .inputValidator((input) => ClaimIdInput.parse(input))
  .handler(async ({ data }) => {
    const sb = supabaseAdmin;
    const [claimRes, docsRes, fieldsRes] = await Promise.all([
      sb.from("claims").select("*").eq("id", data.claimId).maybeSingle(),
      sb
        .from("claim_documents")
        .select("*")
        .eq("claim_id", data.claimId)
        .order("document_type"),
      sb
        .from("extracted_fields")
        .select("field_name")
        .eq("claim_id", data.claimId),
    ]);

    const docs = docsRes.data ?? [];

    const signed = await Promise.all(
      docs.map(async (d) => {
        if (!d.storage_path) return { id: d.id, url: null as string | null };
        const { data: s } = await sb.storage
          .from("claim-documents")
          .createSignedUrl(d.storage_path, 60 * 60);
        return { id: d.id, url: s?.signedUrl ?? null };
      }),
    );
    const urlMap = new Map(signed.map((s) => [s.id, s.url]));

    return {
      claim: claimRes.data,
      documents: docs.map((d) => ({ ...d, signed_url: urlMap.get(d.id) ?? null })),
      hasExtractedFields: (fieldsRes.data?.length ?? 0) > 0,
      extractedFieldCount: fieldsRes.data?.length ?? 0,
    };
  });

export const getExtractedFields = createServerFn({ method: "GET" })
  .inputValidator((input) => ClaimIdInput.parse(input))
  .handler(async ({ data }) => {
    const sb = supabaseAdmin;
    const [claimRes, fieldsRes, docsRes] = await Promise.all([
      sb.from("claims").select("claim_id, demo_scenario").eq("id", data.claimId).maybeSingle(),
      sb
        .from("extracted_fields")
        .select("*")
        .eq("claim_id", data.claimId)
        .order("field_name"),
      sb
        .from("claim_documents")
        .select("id, document_type, file_name")
        .eq("claim_id", data.claimId),
    ]);
    const docMap = new Map((docsRes.data ?? []).map((d) => [d.id, d]));
    const fields = (fieldsRes.data ?? []).map((f) => ({
      ...f,
      document_type: docMap.get(f.document_id)?.document_type ?? "unknown",
      file_name: docMap.get(f.document_id)?.file_name ?? null,
    }));
    return { claim: claimRes.data, fields };
  });

export const getExtractedFacts = createServerFn({ method: "GET" })
  .inputValidator((input) => ClaimIdInput.parse(input))
  .handler(async ({ data }) => {
    const sb = supabaseAdmin;
    const [claimRes, factsRes, docsRes] = await Promise.all([
      sb.from("claims").select("claim_id, demo_scenario").eq("id", data.claimId).maybeSingle(),
      sb
        .from("extracted_facts")
        .select("*")
        .eq("claim_id", data.claimId)
        .order("fact_type", { ascending: true })
        .order("confidence", { ascending: false }),
      sb
        .from("claim_documents")
        .select("id, document_type")
        .eq("claim_id", data.claimId),
    ]);
    const docMap = new Map((docsRes.data ?? []).map((d) => [d.id, d.document_type]));
    const facts = (factsRes.data ?? []).map((f) => ({
      ...f,
      document_type: docMap.get(f.source_document_id ?? "") ?? "unknown",
    }));
    return { claim: claimRes.data, facts };
  });


async function buildEvidenceContext(claimId: string) {
  const sb = supabaseAdmin;
  const [factsRes, fieldsRes, docsRes] = await Promise.all([
    sb.from("extracted_facts").select("id, fact_text, fact_type, confidence, source_document_id").eq("claim_id", claimId),
    sb.from("extracted_fields").select("id, field_name, raw_value, normalized_value, confidence, document_id").eq("claim_id", claimId),
    sb.from("claim_documents").select("id, document_type, file_name").eq("claim_id", claimId),
  ]);
  const docMap = new Map((docsRes.data ?? []).map((d) => [d.id, d]));
  const factMap = new Map((factsRes.data ?? []).map((f) => [f.id, { ...f, document_type: docMap.get(f.source_document_id ?? "")?.document_type ?? "unknown" }]));
  const fieldMap = new Map((fieldsRes.data ?? []).map((f) => [f.id, { ...f, document_type: docMap.get(f.document_id ?? "")?.document_type ?? "unknown" }]));
  return { docMap, factMap, fieldMap };
}

export const getTriggeredRules = createServerFn({ method: "GET" })
  .inputValidator((input) => ClaimIdInput.parse(input))
  .handler(async ({ data }) => {
    const sb = supabaseAdmin;
    const [claimRes, rulesRes, ctx] = await Promise.all([
      sb.from("claims").select("claim_id, demo_scenario").eq("id", data.claimId).maybeSingle(),
      sb.from("triggered_rules").select("*").eq("claim_id", data.claimId),
      buildEvidenceContext(data.claimId),
    ]);
    const rules = rulesRes.data ?? [];
    const ruleIds = Array.from(new Set(rules.map((r) => r.rule_id).filter(Boolean))) as string[];
    let masterMap = new Map<string, { description: string | null; rule_type: string | null }>();
    if (ruleIds.length) {
      const { data: masters } = await sb
        .from("master_rules")
        .select("rule_id, description, rule_type")
        .in("rule_id", ruleIds);
      masterMap = new Map((masters ?? []).map((m) => [m.rule_id, { description: m.description, rule_type: m.rule_type }]));
    }
    const enriched = rules.map((r) => ({
      ...r,
      master_description: masterMap.get(r.rule_id ?? "")?.description ?? null,
      master_rule_type: masterMap.get(r.rule_id ?? "")?.rule_type ?? null,
      source_facts: (r.source_fact_ids ?? []).map((id: string) => ctx.factMap.get(id)).filter(Boolean),
      source_fields: (r.source_field_ids ?? []).map((id: string) => ctx.fieldMap.get(id)).filter(Boolean),
      source_documents: (r.source_document_ids ?? []).map((id: string) => ctx.docMap.get(id)).filter(Boolean),
    }));
    return { claim: claimRes.data, rules: enriched };
  });

export const getContradictions = createServerFn({ method: "GET" })
  .inputValidator((input) => ClaimIdInput.parse(input))
  .handler(async ({ data }) => {
    const sb = supabaseAdmin;
    const [claimRes, contraRes, ctx] = await Promise.all([
      sb.from("claims").select("claim_id, demo_scenario").eq("id", data.claimId).maybeSingle(),
      sb.from("contradictions").select("*").eq("claim_id", data.claimId).order("created_at", { ascending: true }),
      buildEvidenceContext(data.claimId),
    ]);
    const enriched = (contraRes.data ?? []).map((c) => ({
      ...c,
      source_facts: (c.source_fact_ids ?? []).map((id: string) => ctx.factMap.get(id)).filter(Boolean),
      source_fields: (c.source_field_ids ?? []).map((id: string) => ctx.fieldMap.get(id)).filter(Boolean),
      source_documents: (c.source_document_ids ?? []).map((id: string) => ctx.docMap.get(id)).filter(Boolean),
    }));
    return { claim: claimRes.data, contradictions: enriched };
  });

export const getFraudRingPatterns = createServerFn({ method: "GET" })
  .inputValidator((input) => ClaimIdInput.parse(input))
  .handler(async ({ data }) => {
    const sb = supabaseAdmin;
    const [claimRes, patternsRes, resolvedRes] = await Promise.all([
      sb.from("claims").select("claim_id, demo_scenario").eq("id", data.claimId).maybeSingle(),
      sb.from("fraud_ring_patterns").select("*").eq("claim_id", data.claimId).order("severity"),
      sb.from("resolved_entities").select("id, entity_type, canonical_value").eq("claim_id", data.claimId),
    ]);
    const resMap = new Map((resolvedRes.data ?? []).map((r) => [r.id, r]));
    const patterns = (patternsRes.data ?? []).map((p) => ({
      ...p,
      shared_entities: ((p.shared_entity_ids ?? []) as unknown as string[])
        .map((id) => resMap.get(id))
        .filter(Boolean),
    }));
    return { claim: claimRes.data, patterns };
  });

export const getInvestigationQuestions = createServerFn({ method: "GET" })
  .inputValidator((input) => ClaimIdInput.parse(input))
  .handler(async ({ data }) => {
    const sb = supabaseAdmin;
    const [claimRes, qRes, rulesRes, contraRes, fraudRes] = await Promise.all([
      sb.from("claims").select("claim_id, demo_scenario").eq("id", data.claimId).maybeSingle(),
      sb.from("proactive_questions").select("*").eq("claim_id", data.claimId).order("created_at", { ascending: true }),
      sb.from("triggered_rules").select("id, rule_id, rule_name, severity").eq("claim_id", data.claimId),
      sb.from("contradictions").select("id, contradiction_type, description, severity").eq("claim_id", data.claimId),
      sb.from("fraud_ring_patterns").select("id, pattern_type, pattern_name, severity").eq("claim_id", data.claimId),
    ]);
    const ruleMap = new Map((rulesRes.data ?? []).map((r) => [r.id, r]));
    const contraMap = new Map((contraRes.data ?? []).map((c) => [c.id, c]));
    const fraudMap = new Map((fraudRes.data ?? []).map((f) => [f.id, f]));
    const questions = (qRes.data ?? []).map((q) => ({
      ...q,
      source_rule: q.source_rule_id ? ruleMap.get(q.source_rule_id) ?? null : null,
      source_contradiction: q.source_contradiction_id ? contraMap.get(q.source_contradiction_id) ?? null : null,
      source_fraud_pattern: q.source_fraud_pattern_id ? fraudMap.get(q.source_fraud_pattern_id) ?? null : null,
    }));
    return { claim: claimRes.data, questions };
  });

export const getClaimEntities = createServerFn({ method: "GET" })
  .inputValidator((input) => ClaimIdInput.parse(input))
  .handler(async ({ data }) => {
    const sb = supabaseAdmin;
    const [claimRes, resolvedRes, nodesRes, edgesRes, docsRes] = await Promise.all([
      sb.from("claims").select("claim_id, demo_scenario").eq("id", data.claimId).maybeSingle(),
      sb.from("resolved_entities").select("*").eq("claim_id", data.claimId),
      sb.from("entity_nodes").select("*").eq("claim_id", data.claimId),
      sb.from("entity_edges").select("*").eq("claim_id", data.claimId).eq("relationship_type", "historical_match"),
      sb.from("claim_documents").select("id, document_type, file_name").eq("claim_id", data.claimId),
    ]);
    const docMap = new Map((docsRes.data ?? []).map((d) => [d.id, d]));
    const nodes = nodesRes.data ?? [];
    const edges = edgesRes.data ?? [];

    const resolved = (resolvedRes.data ?? []).map((re) => {
      const mentions = nodes
        .filter((n) => n.resolved_entity_id === re.id && n.node_type !== "historical_claim")
        .map((n) => ({
          id: n.id,
          raw_mention: n.raw_mention,
          label: n.label,
          document_type: n.source_document_id ? docMap.get(n.source_document_id)?.document_type ?? "unknown" : "unknown",
          document_id: n.source_document_id,
        }));
      const myMentionIds = new Set(mentions.map((m) => m.id));
      const historical = edges
        .filter((e) => myMentionIds.has(e.source_node_id))
        .map((e) => (e.properties ?? {}) as Record<string, string | number | boolean | null>);
      return {
        id: re.id,
        entity_type: re.entity_type,
        canonical_value: re.canonical_value,
        confidence: re.confidence,
        resolution_method: re.resolution_method,
        mentions,
        historical,
      };
    });
    return { claim: claimRes.data, resolved };
  });

export const getClaimScore = createServerFn({ method: "GET" })
  .inputValidator((input) => ClaimIdInput.parse(input))
  .handler(async ({ data }) => {
    const sb = supabaseAdmin;
    const [claimRes, sqcRes, questionsRes] = await Promise.all([
      sb.from("claims").select("claim_id, demo_scenario").eq("id", data.claimId).maybeSingle(),
      sb.from("sqc_results").select("*").eq("claim_id", data.claimId).order("created_at", { ascending: false }).limit(1).maybeSingle(),
      sb.from("proactive_questions").select("*").eq("claim_id", data.claimId).order("priority", { ascending: false }),
    ]);
    return { claim: claimRes.data, sqc: sqcRes.data, questions: questionsRes.data ?? [] };
  });

export const getClaimFinalPayload = createServerFn({ method: "GET" })
  .inputValidator((input) => ClaimIdInput.parse(input))
  .handler(async ({ data }) => {
    const sb = supabaseAdmin;
    const [claimRes, sqcRes] = await Promise.all([
      sb.from("claims").select("claim_id, demo_scenario").eq("id", data.claimId).maybeSingle(),
      sb.from("sqc_results").select("final_payload, created_at").eq("claim_id", data.claimId).order("created_at", { ascending: false }).limit(1).maybeSingle(),
    ]);
    return { claim: claimRes.data, payload: sqcRes.data?.final_payload ?? null, generated_at: sqcRes.data?.created_at ?? null };
  });
