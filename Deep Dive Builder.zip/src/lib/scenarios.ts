// Per-document scenario outputs used by the demo orchestrator.
// Each scenario now declares facts and fields PER document. Cross-document
// inferences live in `contradictions`, not in `facts`. Entity mentions per
// document feed into `resolved_entities` via shared `resolved_key`.

export type ScenarioKey =
  | "low_risk"
  | "close_proximity_high_value"
  | "timeline_contradiction"
  | "entity_mismatch";

export interface ScenarioField {
  field_name: string;
  raw_value: string;
  normalized_value: string;
  confidence: number;
}

export interface ScenarioFact {
  key: string; // used to wire contradictions to specific facts
  fact_text: string;
  fact_type: string;
  confidence: number;
}

export interface ScenarioEntityMention {
  resolved_key: string; // links to resolved_entities[].key
  node_type: string;
  raw_mention: string;
  label: string;
}

export interface ScenarioDocument {
  document_type: string;
  ocr_text: string;
  fields: ScenarioField[];
  facts: ScenarioFact[];
  entity_mentions: ScenarioEntityMention[];
}

export interface ScenarioResolvedEntity {
  key: string;
  entity_type: string;
  canonical_value: string;
  confidence: number;
  resolution_method: string;
}

export interface ScenarioFieldRef {
  document_type: string;
  field_name: string;
}

export interface ScenarioFactRef {
  document_type: string;
  fact_key: string;
}

export interface ScenarioContradiction {
  contradiction_type: string;
  severity: "low" | "medium" | "high";
  description: string;
  explanation: string;
  recommended_followup: string;
  sides: Array<{ document_type: string; fact_key: string }>;
  source_field_refs?: ScenarioFieldRef[];
}

export interface ScenarioRule {
  rule_id: string;
  rule_name: string;
  category: string;
  severity: "low" | "medium" | "high";
  description: string;
  confidence: number;
  source_fact_refs?: ScenarioFactRef[];
  source_field_refs?: ScenarioFieldRef[];
}

export interface ScenarioFraudPattern {
  pattern_type: string;
  pattern_name: string;
  severity: "low" | "medium" | "high";
  description: string;
  explanation: string;
  shared_entity_keys: string[];
  historical_claim_ids: string[];
  confidence: number;
}

export interface ScenarioQuestionNextStep {
  type: string;
  detail?: string;
  party?: string;
  document_type?: string;
  location?: string;
}

export interface ScenarioQuestion {
  question: string;
  priority: "low" | "medium" | "high";
  source_type: "rule" | "contradiction" | "fraud_ring" | "auxiliary";
  source_rule_id?: string;
  source_contradiction_type?: string;
  source_fraud_pattern_type?: string;
  directed_to: string;
  rationale: string;
  next_steps: ScenarioQuestionNextStep[];
}

export interface ScenarioOutput {
  documents: ScenarioDocument[];
  resolved_entities: ScenarioResolvedEntity[];
  contradictions: ScenarioContradiction[];
  triggered_rules: ScenarioRule[];
  fraud_ring_patterns: ScenarioFraudPattern[];
  questions: ScenarioQuestion[];
  checklist: Array<{ document_type: string; status: "present" | "missing"; mandatory: boolean; reason?: string }>;
  score: {
    risk_score: number;
    risk_category: "Low" | "Medium" | "High";
    recommended_action: "DESKTOP_REVIEW" | "DESKTOP_INVESTIGATION" | "FIELD_INVESTIGATION";
    component_scores: Record<string, number>;
    key_findings: string[];
    narrative: string;
  };
}

// --- Shared entity canonicals ----------------------------------------------

const RAHUL = {
  key: "person_rahul_sharma",
  entity_type: "person",
  canonical_value: "Rahul Sharma",
  confidence: 0.98,
  resolution_method: "exact_match",
};

const VEHICLE_KA01 = {
  key: "vehicle_ka01ab1234",
  entity_type: "vehicle",
  canonical_value: "KA-01-AB-1234",
  confidence: 1,
  resolution_method: "exact_match",
};

// --- Scenarios -------------------------------------------------------------

export const SCENARIOS: Record<ScenarioKey, ScenarioOutput> = {
  // --------------------------------------------------------------- low_risk
  low_risk: {
    documents: [
      {
        document_type: "claim_form",
        ocr_text:
          "MOTOR CLAIM FORM\nPolicy No: POL-MOT-2025-88421\nInsured: Rahul Sharma\nVehicle: KA-01-AB-1234\nDate of loss: 12/04/2026 at 14:35\nLocation: MG Road, Bengaluru\nDriver: Rahul Sharma\nClaim amount: INR 42,500",
        fields: [
          { field_name: "policy_number", raw_value: "POL-MOT-2025-88421", normalized_value: "POL-MOT-2025-88421", confidence: 0.98 },
          { field_name: "claimant_name", raw_value: "Rahul Sharma", normalized_value: "Rahul Sharma", confidence: 0.96 },
          { field_name: "driver_name", raw_value: "Rahul Sharma", normalized_value: "Rahul Sharma", confidence: 0.95 },
          { field_name: "incident_date", raw_value: "12/04/2026", normalized_value: "2026-04-12", confidence: 0.95 },
          { field_name: "incident_time", raw_value: "14:35", normalized_value: "14:35", confidence: 0.93 },
          { field_name: "claim_amount", raw_value: "42500", normalized_value: "42500", confidence: 0.97 },
        ],
        facts: [
          { key: "cf_incident_when", fact_text: "Incident occurred on 2026-04-12 at 14:35 per the claim form", fact_type: "temporal", confidence: 0.95 },
          { key: "cf_driver", fact_text: "Driver named on the claim form is Rahul Sharma", fact_type: "entity", confidence: 0.95 },
          { key: "cf_amount", fact_text: "Claim amount reported on the claim form is ₹42,500", fact_type: "financial", confidence: 0.97 },
        ],
        entity_mentions: [
          { resolved_key: RAHUL.key, node_type: "person", raw_mention: "Rahul Sharma", label: "Insured / Driver" },
          { resolved_key: VEHICLE_KA01.key, node_type: "vehicle", raw_mention: "KA-01-AB-1234", label: "Insured vehicle" },
        ],
      },
      {
        document_type: "policy_copy",
        ocr_text:
          "POLICY SCHEDULE\nPolicy No: POL-MOT-2025-88421\nName of insured: Rahul Sharma\nPeriod: 01/01/2026 to 31/12/2026\nRegistered vehicle: KA-01-AB-1234",
        fields: [
          { field_name: "policy_number", raw_value: "POL-MOT-2025-88421", normalized_value: "POL-MOT-2025-88421", confidence: 0.99 },
          { field_name: "policy_start_date", raw_value: "01/01/2026", normalized_value: "2026-01-01", confidence: 0.98 },
          { field_name: "policy_end_date", raw_value: "31/12/2026", normalized_value: "2026-12-31", confidence: 0.98 },
          { field_name: "insured_name", raw_value: "Rahul Sharma", normalized_value: "Rahul Sharma", confidence: 0.98 },
        ],
        facts: [
          { key: "pol_active", fact_text: "Policy POL-MOT-2025-88421 was active from 2026-01-01 to 2026-12-31", fact_type: "policy", confidence: 0.99 },
          { key: "pol_insured", fact_text: "Policy holder per the policy schedule is Rahul Sharma", fact_type: "entity", confidence: 0.98 },
        ],
        entity_mentions: [
          { resolved_key: RAHUL.key, node_type: "person", raw_mention: "Rahul Sharma", label: "Policy holder" },
          { resolved_key: VEHICLE_KA01.key, node_type: "vehicle", raw_mention: "KA-01-AB-1234", label: "Registered vehicle" },
        ],
      },
      {
        document_type: "rc_book",
        ocr_text: "REGISTRATION CERTIFICATE\nReg No: KA-01-AB-1234\nOwner: Rahul Sharma",
        fields: [
          { field_name: "vehicle_registration_number", raw_value: "KA01AB1234", normalized_value: "KA-01-AB-1234", confidence: 0.97 },
          { field_name: "owner_name", raw_value: "Rahul Sharma", normalized_value: "Rahul Sharma", confidence: 0.96 },
        ],
        facts: [
          { key: "rc_owner", fact_text: "RC book shows owner of KA-01-AB-1234 as Rahul Sharma", fact_type: "entity", confidence: 0.96 },
        ],
        entity_mentions: [
          { resolved_key: RAHUL.key, node_type: "person", raw_mention: "Rahul Sharma", label: "Registered owner" },
          { resolved_key: VEHICLE_KA01.key, node_type: "vehicle", raw_mention: "KA-01-AB-1234", label: "Registered vehicle" },
        ],
      },
      {
        document_type: "driving_license",
        ocr_text: "DRIVING LICENCE\nName: Rahul Sharma\nDL No: DL-KA-2019-0099887",
        fields: [
          { field_name: "license_holder_name", raw_value: "Rahul Sharma", normalized_value: "Rahul Sharma", confidence: 0.95 },
          { field_name: "license_number", raw_value: "DL-KA-2019-0099887", normalized_value: "DL-KA-2019-0099887", confidence: 0.94 },
        ],
        facts: [
          { key: "dl_holder", fact_text: "Driving licence DL-KA-2019-0099887 is held by Rahul Sharma", fact_type: "entity", confidence: 0.95 },
        ],
        entity_mentions: [
          { resolved_key: RAHUL.key, node_type: "person", raw_mention: "Rahul Sharma", label: "Licence holder" },
        ],
      },
      {
        document_type: "repair_estimate",
        ocr_text: "REPAIR ESTIMATE\nGarage: Trusted Motors\nVehicle: KA-01-AB-1234\nEstimate: INR 42,500",
        fields: [
          { field_name: "garage_name", raw_value: "Trusted Motors", normalized_value: "Trusted Motors", confidence: 0.93 },
          { field_name: "estimate_amount", raw_value: "42500", normalized_value: "42500", confidence: 0.95 },
        ],
        facts: [
          { key: "re_garage", fact_text: "Repair estimated by Trusted Motors at ₹42,500", fact_type: "financial", confidence: 0.95 },
        ],
        entity_mentions: [
          { resolved_key: "garage_trusted_motors", node_type: "garage", raw_mention: "Trusted Motors", label: "Repair garage" },
          { resolved_key: VEHICLE_KA01.key, node_type: "vehicle", raw_mention: "KA-01-AB-1234", label: "Vehicle in workshop" },
        ],
      },
    ],
    resolved_entities: [
      RAHUL,
      VEHICLE_KA01,
      { key: "garage_trusted_motors", entity_type: "organization", canonical_value: "Trusted Motors", confidence: 0.95, resolution_method: "exact_match" },
    ],
    contradictions: [],
    triggered_rules: [],
    fraud_ring_patterns: [],
    questions: [
      {
        question:
          "Confirm by phone that the insured is satisfied with the inspection and no additional damages were missed.",
        priority: "low",
        source_type: "auxiliary",
        directed_to: "Insured",
        rationale: "Standard post-inspection courtesy check before settlement.",
        next_steps: [{ type: "call", party: "Insured" }],
      },
    ],
    checklist: [
      { document_type: "claim_form", status: "present", mandatory: true },
      { document_type: "policy_copy", status: "present", mandatory: true },
      { document_type: "rc_book", status: "present", mandatory: true },
      { document_type: "driving_license", status: "present", mandatory: true },
      { document_type: "repair_estimate", status: "present", mandatory: true },
    ],
    score: {
      risk_score: 18,
      risk_category: "Low",
      recommended_action: "DESKTOP_REVIEW",
      component_scores: { temporal: 5, financial: 8, entity: 2, documents: 3, historical: 0 },
      key_findings: ["No rules triggered", "No contradictions detected", "Complete documentation"],
      narrative:
        "Standard OD claim with complete documentation, low value, and no inconsistencies. Recommend desktop review and straight-through processing.",
    },
  },

  // -------------------------------------------- close_proximity_high_value
  close_proximity_high_value: {
    documents: [
      {
        document_type: "claim_form",
        ocr_text:
          "MOTOR CLAIM FORM\nPolicy No: POL-MOT-2026-99001\nInsured: Rahul Sharma\nDate of loss: 05/03/2026 14:00\nClaim amount: INR 3,85,000",
        fields: [
          { field_name: "policy_number", raw_value: "POL-MOT-2026-99001", normalized_value: "POL-MOT-2026-99001", confidence: 0.97 },
          { field_name: "claimant_name", raw_value: "Rahul Sharma", normalized_value: "Rahul Sharma", confidence: 0.95 },
          { field_name: "incident_date", raw_value: "05/03/2026", normalized_value: "2026-03-05", confidence: 0.96 },
          { field_name: "claim_amount", raw_value: "385000", normalized_value: "385000", confidence: 0.98 },
        ],
        facts: [
          { key: "cf_incident_date", fact_text: "Claim form states incident date 2026-03-05", fact_type: "temporal", confidence: 0.96 },
          { key: "cf_amount", fact_text: "Claim amount per claim form is ₹3,85,000", fact_type: "financial", confidence: 0.98 },
        ],
        entity_mentions: [
          { resolved_key: RAHUL.key, node_type: "person", raw_mention: "Rahul Sharma", label: "Insured" },
        ],
      },
      {
        document_type: "policy_copy",
        ocr_text:
          "POLICY SCHEDULE\nPolicy No: POL-MOT-2026-99001\nInsured: Rahul Sharma\nPeriod: 22/02/2026 to 21/02/2027",
        fields: [
          { field_name: "policy_number", raw_value: "POL-MOT-2026-99001", normalized_value: "POL-MOT-2026-99001", confidence: 0.99 },
          { field_name: "policy_start_date", raw_value: "22/02/2026", normalized_value: "2026-02-22", confidence: 0.99 },
          { field_name: "policy_end_date", raw_value: "21/02/2027", normalized_value: "2027-02-21", confidence: 0.99 },
        ],
        facts: [
          { key: "pol_start", fact_text: "Policy POL-MOT-2026-99001 inception date is 2026-02-22", fact_type: "policy", confidence: 0.99 },
        ],
        entity_mentions: [
          { resolved_key: RAHUL.key, node_type: "person", raw_mention: "Rahul Sharma", label: "Policy holder" },
        ],
      },
      {
        document_type: "rc_book",
        ocr_text: "REGISTRATION CERTIFICATE\nReg No: KA-01-AB-1234\nOwner: Rahul Sharma",
        fields: [
          { field_name: "vehicle_registration_number", raw_value: "KA01AB1234", normalized_value: "KA-01-AB-1234", confidence: 0.97 },
        ],
        facts: [
          { key: "rc_owner", fact_text: "RC book shows vehicle KA-01-AB-1234 registered to Rahul Sharma", fact_type: "entity", confidence: 0.95 },
        ],
        entity_mentions: [
          { resolved_key: VEHICLE_KA01.key, node_type: "vehicle", raw_mention: "KA-01-AB-1234", label: "Registered vehicle" },
        ],
      },
      {
        document_type: "driving_license",
        ocr_text: "DRIVING LICENCE\nName: Rahul Sharma",
        fields: [
          { field_name: "license_holder_name", raw_value: "Rahul Sharma", normalized_value: "Rahul Sharma", confidence: 0.94 },
        ],
        facts: [
          { key: "dl_holder", fact_text: "Driving licence is held by Rahul Sharma", fact_type: "entity", confidence: 0.94 },
        ],
        entity_mentions: [
          { resolved_key: RAHUL.key, node_type: "person", raw_mention: "Rahul Sharma", label: "Licence holder" },
        ],
      },
      {
        document_type: "fir",
        ocr_text: "FIR No 4421/2026\nLocation: MG Road\nDate: 05/03/2026",
        fields: [
          { field_name: "fir_number", raw_value: "4421/2026", normalized_value: "FIR-4421-2026", confidence: 0.9 },
        ],
        facts: [
          { key: "fir_when", fact_text: "FIR registered for incident on 2026-03-05", fact_type: "temporal", confidence: 0.9 },
        ],
        entity_mentions: [],
      },
      {
        document_type: "repair_estimate",
        ocr_text:
          "REPAIR ESTIMATE\nGarage: QuickFix Motors\nEstimate: INR 3,85,000",
        fields: [
          { field_name: "garage_name", raw_value: "QuickFix Motors", normalized_value: "QuickFix Motors", confidence: 0.93 },
          { field_name: "estimate_amount", raw_value: "385000", normalized_value: "385000", confidence: 0.96 },
        ],
        facts: [
          { key: "re_garage", fact_text: "Repair estimated by QuickFix Motors at ₹3,85,000", fact_type: "financial", confidence: 0.96 },
        ],
        entity_mentions: [
          { resolved_key: "garage_quickfix", node_type: "garage", raw_mention: "QuickFix Motors", label: "Repair garage (flagged)" },
        ],
      },
    ],
    resolved_entities: [
      RAHUL,
      VEHICLE_KA01,
      { key: "garage_quickfix", entity_type: "organization", canonical_value: "QuickFix Motors", confidence: 0.96, resolution_method: "exact_match" },
    ],
    contradictions: [],
    triggered_rules: [
      {
        rule_id: "R-TEMP-002",
        rule_name: "Close Proximity to Policy Inception",
        category: "Temporal",
        severity: "high",
        description: "Incident occurred within 30 days of policy start date",
        confidence: 0.99,
        source_fact_refs: [
          { document_type: "claim_form", fact_key: "cf_incident_date" },
          { document_type: "policy_copy", fact_key: "pol_start" },
        ],
        source_field_refs: [
          { document_type: "claim_form", field_name: "incident_date" },
          { document_type: "policy_copy", field_name: "policy_start_date" },
        ],
      },
      {
        rule_id: "R-FIN-001",
        rule_name: "High-Value Claim Threshold",
        category: "Financial",
        severity: "high",
        description: "Claim amount exceeds ₹2,00,000 high-value threshold",
        confidence: 1,
        source_fact_refs: [{ document_type: "claim_form", fact_key: "cf_amount" }],
        source_field_refs: [{ document_type: "claim_form", field_name: "claim_amount" }],
      },
      {
        rule_id: "R-GAR-001",
        rule_name: "Repeated Garage Pattern",
        category: "Garage",
        severity: "medium",
        description: "Garage involved in 3+ prior claims in last 12 months",
        confidence: 0.88,
        source_fact_refs: [{ document_type: "repair_estimate", fact_key: "re_garage" }],
        source_field_refs: [{ document_type: "repair_estimate", field_name: "garage_name" }],
      },
    ],
    fraud_ring_patterns: [
      {
        pattern_type: "repeat_garage_ring",
        pattern_name: "Repeat Garage Ring — QuickFix Motors",
        severity: "high",
        description: "QuickFix Motors recurs across suspicious historical claims tied to this insured.",
        explanation:
          "QuickFix Motors appears on multiple historical claims (HC-2024-3322, HC-2025-2044) that were flagged suspicious. The 2025 claim also involves the same insured (Rahul Sharma) and vehicle (KA-01-AB-1234), indicating a recurring insured–garage relationship.",
        shared_entity_keys: ["garage_quickfix", "person_rahul_sharma", "vehicle_ka01ab1234"],
        historical_claim_ids: ["HC-2024-3322", "HC-2025-2044"],
        confidence: 0.86,
      },
    ],
    questions: [
      {
        question:
          "Why was the policy purchased only 11 days before the incident? Obtain prior insurance history.",
        priority: "high",
        source_type: "rule",
        source_rule_id: "R-TEMP-002",
        directed_to: "Insured",
        rationale: "Close proximity to policy inception rule triggered.",
        next_steps: [
          { type: "call", party: "Insured" },
          { type: "collect_document", document_type: "prior_insurance_certificate" },
        ],
      },
      {
        question:
          "Validate repair scope and invoice against estimate; request itemised parts list with serial numbers.",
        priority: "high",
        source_type: "rule",
        source_rule_id: "R-FIN-001",
        directed_to: "Garage",
        rationale: "High-value claim threshold breached; verify parts authenticity and labour.",
        next_steps: [
          { type: "collect_document", document_type: "itemised_invoice" },
          { type: "site_visit", location: "Garage" },
        ],
      },
      {
        question:
          "Conduct on-site inspection of QuickFix Motors and compare workshop records with claimed work.",
        priority: "high",
        source_type: "fraud_ring",
        source_fraud_pattern_type: "repeat_garage_ring",
        directed_to: "Field investigator",
        rationale: "Garage recurs on prior suspicious claims, including one tied to this insured.",
        next_steps: [
          { type: "site_visit", location: "QuickFix Motors" },
          { type: "collect_document", document_type: "garage_workshop_register" },
        ],
      },
      {
        question:
          "Cross-check the insured's relationship with QuickFix Motors — any prior settlements or referrals?",
        priority: "medium",
        source_type: "fraud_ring",
        source_fraud_pattern_type: "repeat_garage_ring",
        directed_to: "Internal",
        rationale: "Repeated insured–garage pairing across historical claims.",
        next_steps: [{ type: "internal_lookup", detail: "Pull insured's prior claim ledger" }],
      },
      {
        question:
          "Obtain spot photographs from the loss location with timestamp and GPS metadata.",
        priority: "medium",
        source_type: "auxiliary",
        directed_to: "Insured",
        rationale: "Spot photographs are missing for a high-value claim.",
        next_steps: [{ type: "collect_document", document_type: "spot_photographs" }],
      },
    ],
    checklist: [
      { document_type: "claim_form", status: "present", mandatory: true },
      { document_type: "policy_copy", status: "present", mandatory: true },
      { document_type: "rc_book", status: "present", mandatory: true },
      { document_type: "driving_license", status: "present", mandatory: true },
      { document_type: "fir", status: "present", mandatory: true },
      { document_type: "spot_photographs", status: "missing", mandatory: false, reason: "Recommended for high-value claims" },
    ],
    score: {
      risk_score: 78,
      risk_category: "High",
      recommended_action: "FIELD_INVESTIGATION",
      component_scores: { temporal: 28, financial: 22, entity: 8, documents: 10, historical: 10 },
      key_findings: [
        "Incident within 11 days of policy start",
        "High-value claim above ₹2L threshold",
        "Garage involved in 3 prior claims",
      ],
      narrative:
        "High-risk claim combining close proximity to policy inception, high claim value, and a repeated-garage pattern. Recommend field investigation with on-site garage validation.",
    },
  },

  // ---------------------------------------------- timeline_contradiction
  timeline_contradiction: {
    documents: [
      {
        document_type: "claim_form",
        ocr_text:
          "MOTOR CLAIM FORM\nInsured: Rahul Sharma\nDate of loss: 12/04/2026 14:35\nLocation: Hosur Road",
        fields: [
          { field_name: "claimant_name", raw_value: "Rahul Sharma", normalized_value: "Rahul Sharma", confidence: 0.95 },
          { field_name: "incident_date", raw_value: "12/04/2026", normalized_value: "2026-04-12", confidence: 0.96 },
          { field_name: "incident_time", raw_value: "14:35", normalized_value: "14:35", confidence: 0.95 },
        ],
        facts: [
          { key: "cf_incident_when", fact_text: "Claim form states the accident occurred on 2026-04-12 at 14:35", fact_type: "temporal", confidence: 0.96 },
          { key: "cf_who", fact_text: "Claim form names Rahul Sharma as the injured party", fact_type: "entity", confidence: 0.95 },
        ],
        entity_mentions: [
          { resolved_key: RAHUL.key, node_type: "person", raw_mention: "Rahul Sharma", label: "Injured party" },
        ],
      },
      {
        document_type: "hospital_bill",
        ocr_text:
          "CITY CARE HOSPITAL\nPatient: Rahul Sharma\nAdmission: 12/04/2026 13:50\nDischarge: 13/04/2026 09:00",
        fields: [
          { field_name: "patient_name", raw_value: "Rahul Sharma", normalized_value: "Rahul Sharma", confidence: 0.95 },
          { field_name: "admission_datetime", raw_value: "12/04/2026 13:50", normalized_value: "2026-04-12T13:50", confidence: 0.94 },
          { field_name: "hospital_name", raw_value: "City Care Hospital", normalized_value: "City Care Hospital", confidence: 0.94 },
        ],
        facts: [
          { key: "hb_admission", fact_text: "Hospital bill shows Rahul Sharma was admitted to City Care Hospital on 2026-04-12 at 13:50", fact_type: "medical", confidence: 0.95 },
        ],
        entity_mentions: [
          { resolved_key: RAHUL.key, node_type: "person", raw_mention: "Rahul Sharma", label: "Patient" },
          { resolved_key: "hosp_city_care", node_type: "organization", raw_mention: "City Care Hospital", label: "Treating hospital" },
        ],
      },
      {
        document_type: "fir",
        ocr_text:
          "FIR No 7782/2026\nLocation: Hosur Road\nDate of incident: 12/04/2026 14:35",
        fields: [
          { field_name: "fir_number", raw_value: "7782/2026", normalized_value: "FIR-7782-2026", confidence: 0.92 },
          { field_name: "incident_date", raw_value: "12/04/2026", normalized_value: "2026-04-12", confidence: 0.93 },
          { field_name: "incident_time", raw_value: "14:35", normalized_value: "14:35", confidence: 0.92 },
        ],
        facts: [
          { key: "fir_when", fact_text: "FIR records incident on Hosur Road on 2026-04-12 at 14:35", fact_type: "temporal", confidence: 0.93 },
        ],
        entity_mentions: [],
      },
      {
        document_type: "policy_copy",
        ocr_text: "POLICY SCHEDULE\nInsured: Rahul Sharma\nPeriod: 01/01/2026 - 31/12/2026",
        fields: [
          { field_name: "policy_start_date", raw_value: "01/01/2026", normalized_value: "2026-01-01", confidence: 0.99 },
        ],
        facts: [
          { key: "pol_active", fact_text: "Policy was active throughout April 2026", fact_type: "policy", confidence: 0.99 },
        ],
        entity_mentions: [{ resolved_key: RAHUL.key, node_type: "person", raw_mention: "Rahul Sharma", label: "Policy holder" }],
      },
      {
        document_type: "rc_book",
        ocr_text: "RC: KA-01-AB-1234, Owner: Rahul Sharma",
        fields: [{ field_name: "vehicle_registration_number", raw_value: "KA01AB1234", normalized_value: "KA-01-AB-1234", confidence: 0.97 }],
        facts: [],
        entity_mentions: [{ resolved_key: VEHICLE_KA01.key, node_type: "vehicle", raw_mention: "KA-01-AB-1234", label: "Insured vehicle" }],
      },
      {
        document_type: "driving_license",
        ocr_text: "DRIVING LICENCE\nName: Rahul Sharma",
        fields: [{ field_name: "license_holder_name", raw_value: "Rahul Sharma", normalized_value: "Rahul Sharma", confidence: 0.94 }],
        facts: [],
        entity_mentions: [{ resolved_key: RAHUL.key, node_type: "person", raw_mention: "Rahul Sharma", label: "Licence holder" }],
      },
      {
        document_type: "repair_estimate",
        ocr_text: "REPAIR ESTIMATE\nGarage: Trusted Motors\nEstimate: INR 88,200",
        fields: [{ field_name: "garage_name", raw_value: "Trusted Motors", normalized_value: "Trusted Motors", confidence: 0.93 }],
        facts: [],
        entity_mentions: [{ resolved_key: "garage_trusted_motors", node_type: "garage", raw_mention: "Trusted Motors", label: "Repair garage" }],
      },
    ],
    resolved_entities: [
      RAHUL,
      VEHICLE_KA01,
      { key: "hosp_city_care", entity_type: "organization", canonical_value: "City Care Hospital", confidence: 0.95, resolution_method: "exact_match" },
      { key: "garage_trusted_motors", entity_type: "organization", canonical_value: "Trusted Motors", confidence: 0.95, resolution_method: "exact_match" },
    ],
    contradictions: [
      {
        contradiction_type: "timeline",
        severity: "high",
        description: "Hospital admission recorded 45 minutes before the claimed incident time",
        explanation:
          "Claim form and FIR both place the accident at 14:35 on 2026-04-12. The hospital bill shows admission at 13:50 the same day. A medical admission cannot precede the accident it relates to.",
        recommended_followup:
          "Re-verify incident time with claimant. Obtain ambulance log and certified hospital case sheet.",
        sides: [
          { document_type: "claim_form", fact_key: "cf_incident_when" },
          { document_type: "hospital_bill", fact_key: "hb_admission" },
        ],
        source_field_refs: [
          { document_type: "claim_form", field_name: "incident_time" },
          { document_type: "hospital_bill", field_name: "admission_datetime" },
        ],
      },
    ],
    triggered_rules: [
      {
        rule_id: "R-TEMP-005",
        rule_name: "Hospital Admission Before Incident",
        category: "Temporal",
        severity: "high",
        description: "Medical timeline inconsistent with claimed incident time",
        confidence: 0.96,
        source_fact_refs: [
          { document_type: "claim_form", fact_key: "cf_incident_when" },
          { document_type: "hospital_bill", fact_key: "hb_admission" },
        ],
        source_field_refs: [
          { document_type: "claim_form", field_name: "incident_time" },
          { document_type: "hospital_bill", field_name: "admission_datetime" },
        ],
      },
    ],
    fraud_ring_patterns: [],
    questions: [
      {
        question:
          "Clarify the exact sequence of events: where was the insured at 13:50 if the accident occurred at 14:35?",
        priority: "high",
        source_type: "contradiction",
        source_contradiction_type: "timeline",
        directed_to: "Insured",
        rationale: "Hospital admission precedes the claimed accident time by 45 minutes.",
        next_steps: [{ type: "call", party: "Insured" }],
      },
      {
        question:
          "Obtain the certified hospital case sheet and the ambulance dispatch log for 2026-04-12.",
        priority: "high",
        source_type: "contradiction",
        source_contradiction_type: "timeline",
        directed_to: "Hospital liaison",
        rationale: "Independent timestamps are needed to reconcile the contradiction.",
        next_steps: [
          { type: "collect_document", document_type: "ambulance_log" },
          { type: "collect_document", document_type: "hospital_case_sheet" },
        ],
      },
      {
        question:
          "Check whether the same vehicle was reported in any concurrent incident or movement log nearby.",
        priority: "medium",
        source_type: "rule",
        source_rule_id: "R-TEMP-005",
        directed_to: "Internal",
        rationale: "Independent corroboration of the incident timing.",
        next_steps: [{ type: "internal_lookup", detail: "Traffic / toll telemetry on 2026-04-12" }],
      },
      {
        question:
          "Request statements from any witnesses present at the loss location.",
        priority: "medium",
        source_type: "auxiliary",
        directed_to: "Insured",
        rationale: "Witness corroboration can resolve the timeline gap.",
        next_steps: [{ type: "collect_document", document_type: "witness_statement" }],
      },
    ],
    checklist: [
      { document_type: "claim_form", status: "present", mandatory: true },
      { document_type: "hospital_bill", status: "present", mandatory: true },
      { document_type: "fir", status: "present", mandatory: true },
      { document_type: "ambulance_log", status: "missing", mandatory: false, reason: "Needed to reconcile timeline" },
    ],
    score: {
      risk_score: 71,
      risk_category: "High",
      recommended_action: "FIELD_INVESTIGATION",
      component_scores: { temporal: 35, financial: 10, entity: 6, documents: 12, historical: 8 },
      key_findings: ["Hospital admission precedes incident time", "Timeline contradiction confirmed across two documents"],
      narrative:
        "Material timeline contradiction between the claim form and hospital records. The medical event cannot precede the incident; recommend field investigation to reconcile the 45-minute discrepancy before settlement.",
    },
  },

  // ------------------------------------------------------- entity_mismatch
  entity_mismatch: {
    documents: [
      {
        document_type: "claim_form",
        ocr_text:
          "MOTOR CLAIM FORM\nPolicy in name of: Rahul Sharma\nDriver at incident: Anil Kumar\nVehicle: KA-01-AB-1234",
        fields: [
          { field_name: "claimant_name", raw_value: "Rahul Sharma", normalized_value: "Rahul Sharma", confidence: 0.96 },
          { field_name: "driver_name", raw_value: "Anil Kumar", normalized_value: "Anil Kumar", confidence: 0.94 },
        ],
        facts: [
          { key: "cf_insured", fact_text: "Claim form names Rahul Sharma as the policy holder", fact_type: "entity", confidence: 0.96 },
          { key: "cf_driver", fact_text: "Claim form names Anil Kumar as the driver at the time of incident", fact_type: "entity", confidence: 0.94 },
        ],
        entity_mentions: [
          { resolved_key: RAHUL.key, node_type: "person", raw_mention: "Rahul Sharma", label: "Insured" },
          { resolved_key: "person_anil_kumar", node_type: "person", raw_mention: "Anil Kumar", label: "Driver" },
        ],
      },
      {
        document_type: "policy_copy",
        ocr_text: "POLICY SCHEDULE\nInsured: Rahul Sharma\nPeriod: 01/01/2026 - 31/12/2026",
        fields: [
          { field_name: "insured_name", raw_value: "Rahul Sharma", normalized_value: "Rahul Sharma", confidence: 0.98 },
        ],
        facts: [
          { key: "pol_insured", fact_text: "Policy schedule lists Rahul Sharma as the sole insured", fact_type: "policy", confidence: 0.98 },
        ],
        entity_mentions: [{ resolved_key: RAHUL.key, node_type: "person", raw_mention: "Rahul Sharma", label: "Policy holder" }],
      },
      {
        document_type: "driving_license",
        ocr_text: "DRIVING LICENCE\nName: Anil Kumar\nDL No: DL-KA-2018-554433",
        fields: [
          { field_name: "license_holder_name", raw_value: "Anil Kumar", normalized_value: "Anil Kumar", confidence: 0.95 },
          { field_name: "license_number", raw_value: "DL-KA-2018-554433", normalized_value: "DL-KA-2018-554433", confidence: 0.94 },
        ],
        facts: [
          { key: "dl_holder", fact_text: "Driving licence DL-KA-2018-554433 is held by Anil Kumar", fact_type: "entity", confidence: 0.95 },
        ],
        entity_mentions: [{ resolved_key: "person_anil_kumar", node_type: "person", raw_mention: "Anil Kumar", label: "Licence holder" }],
      },
      {
        document_type: "rc_book",
        ocr_text: "REGISTRATION CERTIFICATE\nReg No: KA-01-AB-1234\nOwner: Rahul Sharma",
        fields: [
          { field_name: "vehicle_registration_number", raw_value: "KA01AB1234", normalized_value: "KA-01-AB-1234", confidence: 0.97 },
          { field_name: "owner_name", raw_value: "Rahul Sharma", normalized_value: "Rahul Sharma", confidence: 0.96 },
        ],
        facts: [
          { key: "rc_owner", fact_text: "RC book shows owner of KA-01-AB-1234 as Rahul Sharma", fact_type: "entity", confidence: 0.96 },
        ],
        entity_mentions: [
          { resolved_key: RAHUL.key, node_type: "person", raw_mention: "Rahul Sharma", label: "Owner" },
          { resolved_key: VEHICLE_KA01.key, node_type: "vehicle", raw_mention: "KA-01-AB-1234", label: "Vehicle" },
        ],
      },
      {
        document_type: "fir",
        ocr_text: "FIR No 1102/2026\nDriver involved: Mr A Kumar",
        fields: [{ field_name: "driver_name", raw_value: "Mr A Kumar", normalized_value: "Anil Kumar", confidence: 0.7 }],
        facts: [
          { key: "fir_driver", fact_text: "FIR identifies the driver involved as Mr A Kumar", fact_type: "entity", confidence: 0.7 },
        ],
        entity_mentions: [
          { resolved_key: "person_anil_kumar", node_type: "person", raw_mention: "Mr A Kumar", label: "Driver (FIR)" },
        ],
      },
      {
        document_type: "repair_estimate",
        ocr_text: "REPAIR ESTIMATE\nGarage: Trusted Motors\nEstimate: INR 56,000",
        fields: [{ field_name: "garage_name", raw_value: "Trusted Motors", normalized_value: "Trusted Motors", confidence: 0.93 }],
        facts: [],
        entity_mentions: [{ resolved_key: "garage_trusted_motors", node_type: "garage", raw_mention: "Trusted Motors", label: "Repair garage" }],
      },
    ],
    resolved_entities: [
      RAHUL,
      VEHICLE_KA01,
      { key: "person_anil_kumar", entity_type: "person", canonical_value: "Anil Kumar", confidence: 0.88, resolution_method: "fuzzy_name (Anil Kumar / Mr A Kumar)" },
      { key: "garage_trusted_motors", entity_type: "organization", canonical_value: "Trusted Motors", confidence: 0.95, resolution_method: "exact_match" },
    ],
    contradictions: [
      {
        contradiction_type: "entity",
        severity: "medium",
        description: "Driver on claim form does not match insured on policy",
        explanation:
          "The policy schedule lists Rahul Sharma as the sole insured. The claim form (and FIR + DL) name Anil Kumar as the driver at the time of the incident. No authorisation letter is on file.",
        recommended_followup: "Request authorisation letter from policy holder, driver KYC, and statement of relationship.",
        sides: [
          { document_type: "policy_copy", fact_key: "pol_insured" },
          { document_type: "claim_form", fact_key: "cf_driver" },
        ],
        source_field_refs: [
          { document_type: "policy_copy", field_name: "insured_name" },
          { document_type: "claim_form", field_name: "driver_name" },
          { document_type: "driving_license", field_name: "license_holder_name" },
        ],
      },
    ],
    triggered_rules: [
      {
        rule_id: "R-DRV-001",
        rule_name: "Driver-Insured Mismatch",
        category: "Driver",
        severity: "medium",
        description: "Driver at time of incident differs from policy holder without declared authorisation",
        confidence: 0.94,
        source_fact_refs: [
          { document_type: "claim_form", fact_key: "cf_driver" },
          { document_type: "policy_copy", fact_key: "pol_insured" },
          { document_type: "fir", fact_key: "fir_driver" },
        ],
        source_field_refs: [
          { document_type: "claim_form", field_name: "driver_name" },
          { document_type: "policy_copy", field_name: "insured_name" },
          { document_type: "fir", field_name: "driver_name" },
        ],
      },
      {
        rule_id: "R-KYC-001",
        rule_name: "Missing KYC for Driver",
        category: "KYC",
        severity: "medium",
        description: "Driver KYC (Aadhaar/PAN) not on file",
        confidence: 0.9,
        source_fact_refs: [{ document_type: "claim_form", fact_key: "cf_driver" }],
        source_field_refs: [{ document_type: "claim_form", field_name: "driver_name" }],
      },
    ],
    fraud_ring_patterns: [],
    questions: [
      {
        question: "Obtain a signed authorisation letter from Rahul Sharma permitting Anil Kumar to drive the insured vehicle.",
        priority: "high",
        source_type: "rule",
        source_rule_id: "R-DRV-001",
        directed_to: "Insured",
        rationale: "Driver-Insured mismatch without declared authorisation.",
        next_steps: [{ type: "collect_document", document_type: "authorisation_letter" }],
      },
      {
        question: "Record a statement from Rahul Sharma describing the relationship with Anil Kumar.",
        priority: "medium",
        source_type: "contradiction",
        source_contradiction_type: "entity",
        directed_to: "Insured",
        rationale: "Establish the relationship and basis on which the vehicle was driven.",
        next_steps: [{ type: "call", party: "Insured" }],
      },
      {
        question: "Collect Aadhaar/PAN copies for Anil Kumar and verify with KYC database.",
        priority: "medium",
        source_type: "rule",
        source_rule_id: "R-KYC-001",
        directed_to: "Driver",
        rationale: "Driver KYC is missing.",
        next_steps: [
          { type: "collect_document", document_type: "driver_kyc" },
          { type: "internal_lookup", detail: "Run KYC verification" },
        ],
      },
      {
        question: "Confirm Anil Kumar's licence DL-KA-2018-554433 is valid and matches the vehicle class.",
        priority: "medium",
        source_type: "auxiliary",
        directed_to: "Internal",
        rationale: "Independent licence validity check before settlement.",
        next_steps: [{ type: "internal_lookup", detail: "Verify DL with RTO portal" }],
      },
    ],
    checklist: [
      { document_type: "claim_form", status: "present", mandatory: true },
      { document_type: "driving_license", status: "present", mandatory: true },
      { document_type: "authorisation_letter", status: "missing", mandatory: true, reason: "Required when driver ≠ insured" },
      { document_type: "driver_kyc", status: "missing", mandatory: true, reason: "Aadhaar/PAN of driver missing" },
    ],
    score: {
      risk_score: 54,
      risk_category: "Medium",
      recommended_action: "DESKTOP_INVESTIGATION",
      component_scores: { temporal: 4, financial: 10, entity: 22, documents: 14, historical: 4 },
      key_findings: ["Driver does not match insured", "Authorisation letter and driver KYC missing"],
      narrative:
        "Entity mismatch between policy holder and driver, compounded by missing authorisation and KYC documents. Recommend desktop investigation: collect authorisation letter and driver KYC before settlement.",
    },
  },
};
