import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import { SCENARIOS, type ScenarioKey, type ScenarioOutput } from "./scenarios";

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

interface StepDef {
  phase: string;
  agent: string;
  skill: string;
  tool: string;
  message: string;
  delay?: number;
}

const STEPS: StepDef[] = [
  // Phase 1 — Ingestion
  { phase: "Ingestion", agent: "IngestionAgent", skill: "Language Detection", tool: "language.detect", message: "Detected document language (en) for all uploaded files" },
  { phase: "Ingestion", agent: "IngestionAgent", skill: "Translation", tool: "translate", message: "No translation required (en)" },
  { phase: "Ingestion", agent: "IngestionAgent", skill: "Document Classification", tool: "classify.document", message: "Classified documents into known types" },
  { phase: "Ingestion", agent: "IngestionAgent", skill: "OCR", tool: "ocr.extract", message: "Extracted raw text from each document" },
  { phase: "Ingestion", agent: "IngestionAgent", skill: "Field Extraction", tool: "field.extract", message: "Extracted structured fields per document" },

  // Phase 2 — Analysis
  { phase: "Analysis", agent: "AnalysisAgent", skill: "Fact Generation", tool: "fact.generate", message: "Generated per-document atomic facts" },
  { phase: "Analysis", agent: "AnalysisAgent", skill: "Rule Evaluation", tool: "rule.evaluate", message: "Evaluated active master rules against facts" },
  { phase: "Analysis", agent: "AnalysisAgent", skill: "Consistency Checking", tool: "contradiction.compare", message: "Cross-checked facts across documents for contradictions" },

  // Phase 3 — Entity
  { phase: "Entity", agent: "EntityAgent", skill: "Entity Extraction", tool: "entity.extract", message: "Extracted entity mentions per document" },
  { phase: "Entity", agent: "EntityAgent", skill: "Entity Resolution", tool: "entity.resolve", message: "Clustered mentions into canonical entities" },
  { phase: "Entity", agent: "EntityAgent", skill: "Historical Match", tool: "historical.match", message: "Matched resolved entities against historical claims" },
  { phase: "Entity", agent: "EntityAgent", skill: "Fraud Ring Detection", tool: "fraud.detect", message: "Synthesised fraud-ring patterns from historical matches" },

  // Phase 4 — Scoring
  { phase: "Scoring", agent: "ScoringAgent", skill: "Risk Scoring", tool: "score.calculate", message: "Computed risk components and overall score" },
  { phase: "Scoring", agent: "ScoringAgent", skill: "Question Generation", tool: "questions.generate", message: "Drafted grounded investigation questions" },
  { phase: "Scoring", agent: "ScoringAgent", skill: "Question Generation", tool: "checklist.build", message: "Built document checklist" },

  // Phase 5 — Persistence
  { phase: "Persistence", agent: "Supervisor", skill: "Narrative Generation", tool: "narrative.generate", message: "Generated executive narrative" },
  { phase: "Persistence", agent: "Supervisor", skill: "Narrative Generation", tool: "persist.sqc", message: "Persisted investigation result" },

  // Phase 6 — Callback
  { phase: "Callback", agent: "Supervisor", skill: "Narrative Generation", tool: "json.generate", message: "Prepared final JSON payload" },
  { phase: "Callback", agent: "Supervisor", skill: "Narrative Generation", tool: "callback.prepare", message: "Callback envelope ready for downstream system" },
];

const STEP_DELAY_MS = 350;

interface RunState {
  docIdByType: Map<string, string>;
  factIdByKey: Map<string, string>;
  fieldIdByKey: Map<string, string>;
  factConfidenceById: Map<string, number>;
  fieldConfidenceById: Map<string, number>;
  resolvedIdByKey: Map<string, string>;
  ruleRowIdByCode: Map<string, string>;
  contradictionRowIdByType: Map<string, string>;
  fraudPatternRowIdByType: Map<string, string>;
}

async function emit(
  jobId: string,
  claimId: string,
  step: StepDef,
  status: "started" | "completed",
  payload: Record<string, unknown> = {},
) {
  await supabaseAdmin.from("job_events").insert({
    job_id: jobId,
    claim_id: claimId,
    phase: step.phase,
    agent_name: step.agent,
    skill_applied: step.skill,
    tool_used: step.tool,
    status,
    message: step.message,
    payload: payload as never,
    started_at: status === "started" ? new Date().toISOString() : null,
    completed_at: status === "completed" ? new Date().toISOString() : null,
  });
}

export const startPipeline = createServerFn({ method: "POST" })
  .inputValidator((input) => z.object({ claimId: z.string().uuid() }).parse(input))
  .handler(async ({ data }) => {
    const sb = supabaseAdmin;
    const { data: claim, error: claimErr } = await sb
      .from("claims")
      .select("*")
      .eq("id", data.claimId)
      .maybeSingle();
    if (claimErr || !claim) throw new Error("Claim not found");

    const scenarioKey = (claim.demo_scenario ?? "low_risk") as ScenarioKey;
    const scenario = SCENARIOS[scenarioKey] ?? SCENARIOS.low_risk;
    const jobId = `JOB-${Date.now()}-${claim.claim_id}`;

    await Promise.all([
      sb.from("extracted_fields").delete().eq("claim_id", claim.id),
      sb.from("extracted_facts").delete().eq("claim_id", claim.id),
      sb.from("triggered_rules").delete().eq("claim_id", claim.id),
      sb.from("contradictions").delete().eq("claim_id", claim.id),
      sb.from("entity_edges").delete().eq("claim_id", claim.id),
      sb.from("entity_nodes").delete().eq("claim_id", claim.id),
      sb.from("resolved_entities").delete().eq("claim_id", claim.id),
      sb.from("proactive_questions").delete().eq("claim_id", claim.id),
      sb.from("document_checklist").delete().eq("claim_id", claim.id),
      sb.from("fraud_ring_patterns").delete().eq("claim_id", claim.id),
      sb.from("sqc_results").delete().eq("claim_id", claim.id),
      sb.from("job_events").delete().eq("claim_id", claim.id),
    ]);

    const { data: docs } = await sb
      .from("claim_documents")
      .select("id, document_type")
      .eq("claim_id", claim.id);
    const state: RunState = {
      docIdByType: new Map((docs ?? []).map((d) => [d.document_type, d.id])),
      factIdByKey: new Map(),
      fieldIdByKey: new Map(),
      factConfidenceById: new Map(),
      fieldConfidenceById: new Map(),
      resolvedIdByKey: new Map(),
      ruleRowIdByCode: new Map(),
      contradictionRowIdByType: new Map(),
      fraudPatternRowIdByType: new Map(),
    };

    await runPipeline(jobId, claim, scenario, state);
    return { jobId, claimId: claim.id };
  });

async function runPipeline(
  jobId: string,
  claim: { id: string; claim_id: string; demo_scenario: string | null },
  scenario: ScenarioOutput,
  state: RunState,
) {
  const sb = supabaseAdmin;
  const claimId = claim.id;

  for (const step of STEPS) {
    await emit(jobId, claimId, step, "started");
    await sleep(STEP_DELAY_MS);

    try {
      await applyStepSideEffects(step, claim, scenario, state);
    } catch (err) {
      console.error("step failed", step.tool, err);
    }

    await emit(jobId, claimId, step, "completed", summarizeStep(step, scenario));
    await sleep(120);
  }

  await sb.from("claims").update({ status: "completed" }).eq("id", claimId);
}

async function applyStepSideEffects(
  step: StepDef,
  claim: { id: string; claim_id: string },
  scenario: ScenarioOutput,
  state: RunState,
) {
  const sb = supabaseAdmin;

  switch (step.tool) {
    case "ocr.extract": {
      for (const sd of scenario.documents) {
        const docId = state.docIdByType.get(sd.document_type);
        if (!docId) continue;
        await sb
          .from("claim_documents")
          .update({ extracted_text: sd.ocr_text })
          .eq("id", docId);
      }
      break;
    }

    case "field.extract": {
      for (const sd of scenario.documents) {
        const docId = state.docIdByType.get(sd.document_type);
        if (!docId || sd.fields.length === 0) continue;
        const rows = sd.fields.map((f) => ({
          claim_id: claim.id,
          document_id: docId,
          field_uuid: `${claim.claim_id}-${sd.document_type}-${f.field_name}`,
          field_name: f.field_name,
          raw_value: f.raw_value,
          normalized_value: f.normalized_value,
          confidence: f.confidence,
          source_language: "en",
        }));
        const { data: inserted } = await sb
          .from("extracted_fields")
          .insert(rows as never)
          .select("id, field_name, confidence");
        if (inserted) {
          sd.fields.forEach((f, i) => {
            const row = inserted[i];
            if (row) {
              state.fieldIdByKey.set(`${sd.document_type}:${f.field_name}`, row.id);
              state.fieldConfidenceById.set(row.id, Number(row.confidence ?? 0));
            }
          });
        }
      }
      break;
    }

    case "fact.generate": {
      for (const sd of scenario.documents) {
        const docId = state.docIdByType.get(sd.document_type);
        if (!docId || sd.facts.length === 0) continue;
        const rows = sd.facts.map((f) => ({
          claim_id: claim.id,
          source_document_id: docId,
          fact_text: f.fact_text,
          fact_type: f.fact_type,
          confidence: f.confidence,
        }));
        const { data: inserted } = await sb
          .from("extracted_facts")
          .insert(rows as never)
          .select("id, fact_text, confidence");
        if (inserted) {
          sd.facts.forEach((f, i) => {
            const row = inserted[i];
            if (row) {
              state.factIdByKey.set(`${sd.document_type}:${f.key}`, row.id);
              state.factConfidenceById.set(row.id, Number(row.confidence ?? 0));
            }
          });
        }
      }
      break;
    }

    case "rule.evaluate": {
      for (const r of scenario.triggered_rules) {
        const factIds = (r.source_fact_refs ?? [])
          .map((ref) => state.factIdByKey.get(`${ref.document_type}:${ref.fact_key}`))
          .filter((x): x is string => Boolean(x));
        const fieldIds = (r.source_field_refs ?? [])
          .map((ref) => state.fieldIdByKey.get(`${ref.document_type}:${ref.field_name}`))
          .filter((x): x is string => Boolean(x));
        const docIds = Array.from(
          new Set(
            [
              ...(r.source_fact_refs ?? []).map((ref) => state.docIdByType.get(ref.document_type)),
              ...(r.source_field_refs ?? []).map((ref) => state.docIdByType.get(ref.document_type)),
            ].filter((x): x is string => Boolean(x)),
          ),
        );
        const confs = [
          ...factIds.map((id) => state.factConfidenceById.get(id) ?? 1),
          ...fieldIds.map((id) => state.fieldConfidenceById.get(id) ?? 1),
        ];
        const minConf = confs.length ? Math.min(...confs) : null;
        const { data: inserted } = await sb
          .from("triggered_rules")
          .insert({
            claim_id: claim.id,
            rule_id: r.rule_id,
            rule_name: r.rule_name,
            category: r.category,
            severity: r.severity,
            description: r.description,
            confidence: r.confidence,
            evidence: {},
            source_fact_ids: factIds,
            source_field_ids: fieldIds,
            source_document_ids: docIds,
            min_source_confidence: minConf,
          } as never)
          .select("id")
          .single();
        if (inserted) state.ruleRowIdByCode.set(r.rule_id, inserted.id);
      }
      break;
    }

    case "contradiction.compare": {
      for (const c of scenario.contradictions) {
        const factIds = c.sides
          .map((s) => state.factIdByKey.get(`${s.document_type}:${s.fact_key}`))
          .filter((x): x is string => Boolean(x));
        const fieldIds = (c.source_field_refs ?? [])
          .map((ref) => state.fieldIdByKey.get(`${ref.document_type}:${ref.field_name}`))
          .filter((x): x is string => Boolean(x));
        const docIds = Array.from(
          new Set(
            [
              ...c.sides.map((s) => state.docIdByType.get(s.document_type)),
              ...(c.source_field_refs ?? []).map((ref) => state.docIdByType.get(ref.document_type)),
            ].filter((x): x is string => Boolean(x)),
          ),
        );
        const confs = [
          ...factIds.map((id) => state.factConfidenceById.get(id) ?? 1),
          ...fieldIds.map((id) => state.fieldConfidenceById.get(id) ?? 1),
        ];
        const minConf = confs.length ? Math.min(...confs) : null;
        const sides = c.sides.map((s, idx) => ({
          side: idx === 0 ? "A" : "B",
          document_type: s.document_type,
          document_id: state.docIdByType.get(s.document_type) ?? null,
          fact_id: state.factIdByKey.get(`${s.document_type}:${s.fact_key}`) ?? null,
        }));
        const { data: inserted } = await sb
          .from("contradictions")
          .insert({
            claim_id: claim.id,
            contradiction_type: c.contradiction_type,
            severity: c.severity,
            description: c.description,
            explanation: c.explanation,
            recommended_followup: c.recommended_followup,
            facts_involved: sides as never,
            documents_involved: sides.map((s) => ({ side: s.side, document_type: s.document_type })) as never,
            source_fact_ids: factIds,
            source_field_ids: fieldIds,
            source_document_ids: docIds,
            min_source_confidence: minConf,
          } as never)
          .select("id")
          .single();
        if (inserted) state.contradictionRowIdByType.set(c.contradiction_type, inserted.id);
      }
      break;
    }

    case "entity.extract": {
      const rows: Array<Record<string, unknown>> = [];
      for (const sd of scenario.documents) {
        const docId = state.docIdByType.get(sd.document_type);
        if (!docId) continue;
        for (const m of sd.entity_mentions) {
          rows.push({
            claim_id: claim.id,
            source_document_id: docId,
            node_type: m.node_type,
            node_key: `${sd.document_type}:${m.resolved_key}`,
            label: m.label,
            raw_mention: m.raw_mention,
          });
        }
      }
      if (rows.length) await sb.from("entity_nodes").insert(rows as never);
      break;
    }

    case "entity.resolve": {
      const resolvedRows = scenario.resolved_entities.map((r) => ({
        claim_id: claim.id,
        entity_type: r.entity_type,
        canonical_value: r.canonical_value,
        confidence: r.confidence,
        resolution_method: r.resolution_method,
      }));
      if (resolvedRows.length) {
        const { data: inserted } = await sb
          .from("resolved_entities")
          .insert(resolvedRows as never)
          .select("id, canonical_value");
        if (inserted) {
          scenario.resolved_entities.forEach((r, i) => {
            const row = inserted[i];
            if (row) state.resolvedIdByKey.set(r.key, row.id);
          });
        }
      }
      for (const sd of scenario.documents) {
        for (const m of sd.entity_mentions) {
          const resolvedId = state.resolvedIdByKey.get(m.resolved_key);
          if (!resolvedId) continue;
          await sb
            .from("entity_nodes")
            .update({ resolved_entity_id: resolvedId })
            .eq("claim_id", claim.id)
            .eq("node_key", `${sd.document_type}:${m.resolved_key}`);
        }
      }
      break;
    }

    case "fraud.detect": {
      for (const p of scenario.fraud_ring_patterns) {
        const sharedEntityIds = p.shared_entity_keys
          .map((k) => state.resolvedIdByKey.get(k))
          .filter((x): x is string => Boolean(x));
        const { data: inserted } = await sb
          .from("fraud_ring_patterns")
          .insert({
            claim_id: claim.id,
            pattern_type: p.pattern_type,
            pattern_name: p.pattern_name,
            severity: p.severity,
            description: p.description,
            explanation: p.explanation,
            shared_entity_ids: sharedEntityIds as never,
            historical_claim_ids: p.historical_claim_ids as never,
            confidence: p.confidence,
          } as never)
          .select("id")
          .single();
        if (inserted) state.fraudPatternRowIdByType.set(p.pattern_type, inserted.id);
      }
      break;
    }

    case "questions.generate": {
      const rows = scenario.questions.map((q) => {
        const ruleRowId = q.source_rule_id ? state.ruleRowIdByCode.get(q.source_rule_id) ?? null : null;
        const contradictionRowId = q.source_contradiction_type
          ? state.contradictionRowIdByType.get(q.source_contradiction_type) ?? null
          : null;
        const fraudRowId = q.source_fraud_pattern_type
          ? state.fraudPatternRowIdByType.get(q.source_fraud_pattern_type) ?? null
          : null;
        let minConf: number | null = null;
        if (q.source_rule_id) {
          const r = scenario.triggered_rules.find((x) => x.rule_id === q.source_rule_id);
          if (r) minConf = r.confidence;
        }
        return {
          claim_id: claim.id,
          question: q.question,
          priority: q.priority,
          target: q.directed_to,
          directed_to: q.directed_to,
          source_type: q.source_type,
          source_rule_id: ruleRowId,
          source_contradiction_id: contradictionRowId,
          source_fraud_pattern_id: fraudRowId,
          next_steps: q.next_steps as never,
          rationale: q.rationale,
          min_source_confidence: minConf,
        };
      });
      if (rows.length) await sb.from("proactive_questions").insert(rows as never);
      break;
    }

    case "checklist.build": {
      const rows = scenario.checklist.map((c) => ({
        claim_id: claim.id,
        document_type: c.document_type,
        status: c.status,
        mandatory: c.mandatory,
        reason: c.reason ?? null,
      }));
      if (rows.length) await sb.from("document_checklist").insert(rows as never);
      break;
    }

    case "historical.match": {
      const { data: resolved } = await sb
        .from("resolved_entities")
        .select("id, entity_type, canonical_value")
        .eq("claim_id", claim.id);
      if (!resolved || resolved.length === 0) break;

      for (const re of resolved) {
        const val = (re.canonical_value ?? "").trim();
        if (!val) continue;
        const type = re.entity_type;
        const orParts: string[] = [];
        if (type === "person") {
          orParts.push(`claimant_name.ilike.${val}`, `driver_name.ilike.${val}`);
        } else if (type === "vehicle") {
          orParts.push(`vehicle_registration_number.ilike.${val}`);
        } else if (type === "organization") {
          orParts.push(`garage_name.ilike.${val}`, `hospital_name.ilike.${val}`);
        } else {
          continue;
        }
        const { data: matches } = await sb
          .from("historical_claims")
          .select("id, historical_claim_id, claim_type, claim_amount, incident_date, risk_category, suspicious_flag, investigation_outcome, pattern_notes, claimant_name, driver_name, vehicle_registration_number, garage_name, hospital_name")
          .or(orParts.join(","));
        if (!matches || matches.length === 0) continue;

        const { data: nodes } = await sb
          .from("entity_nodes")
          .select("id")
          .eq("claim_id", claim.id)
          .eq("resolved_entity_id", re.id)
          .limit(1);
        const sourceNodeId = nodes?.[0]?.id;
        if (!sourceNodeId) continue;

        for (const hc of matches) {
          const lower = val.toLowerCase();
          let matchField = "unknown";
          if ((hc.claimant_name ?? "").toLowerCase() === lower) matchField = "claimant_name";
          else if ((hc.driver_name ?? "").toLowerCase() === lower) matchField = "driver_name";
          else if ((hc.vehicle_registration_number ?? "").toLowerCase() === lower) matchField = "vehicle_registration_number";
          else if ((hc.garage_name ?? "").toLowerCase() === lower) matchField = "garage_name";
          else if ((hc.hospital_name ?? "").toLowerCase() === lower) matchField = "hospital_name";

          const { data: targetNode } = await sb
            .from("entity_nodes")
            .insert({
              claim_id: claim.id,
              node_type: "historical_claim",
              node_key: `historical:${hc.historical_claim_id}:${re.id}`,
              label: `Historical claim ${hc.historical_claim_id}`,
              raw_mention: hc.historical_claim_id,
              resolved_entity_id: re.id,
              properties: hc as never,
            } as never)
            .select("id")
            .single();
          if (!targetNode) continue;

          await sb.from("entity_edges").insert({
            claim_id: claim.id,
            source_node_id: sourceNodeId,
            target_node_id: targetNode.id,
            relationship_type: "historical_match",
            properties: {
              match_field: matchField,
              historical_claim_id: hc.historical_claim_id,
              suspicious_flag: hc.suspicious_flag,
              risk_category: hc.risk_category,
              claim_amount: hc.claim_amount,
              incident_date: hc.incident_date,
              investigation_outcome: hc.investigation_outcome,
              pattern_notes: hc.pattern_notes,
            },
          } as never);
        }
      }
      break;
    }

    case "persist.sqc": {
      await sb.from("sqc_results").insert({
        claim_id: claim.id,
        job_id: `JOB-${claim.claim_id}`,
        risk_score: scenario.score.risk_score,
        risk_category: scenario.score.risk_category,
        recommended_action: scenario.score.recommended_action,
        component_scores: scenario.score.component_scores,
        key_findings: scenario.score.key_findings,
        narrative: scenario.score.narrative,
        status: "completed",
        final_payload: {},
      } as never);
      break;
    }

    case "json.generate": {
      const [claimRow, fields, facts, rules, contras, resolved, nodes, edges, checklist, questions, sqc, fraud] = await Promise.all([
        sb.from("claims").select("*").eq("id", claim.id).maybeSingle(),
        sb.from("extracted_fields").select("*").eq("claim_id", claim.id),
        sb.from("extracted_facts").select("*").eq("claim_id", claim.id),
        sb.from("triggered_rules").select("*").eq("claim_id", claim.id),
        sb.from("contradictions").select("*").eq("claim_id", claim.id),
        sb.from("resolved_entities").select("*").eq("claim_id", claim.id),
        sb.from("entity_nodes").select("*").eq("claim_id", claim.id),
        sb.from("entity_edges").select("*").eq("claim_id", claim.id),
        sb.from("document_checklist").select("*").eq("claim_id", claim.id),
        sb.from("proactive_questions").select("*").eq("claim_id", claim.id),
        sb.from("sqc_results").select("*").eq("claim_id", claim.id).order("created_at", { ascending: false }).limit(1).maybeSingle(),
        sb.from("fraud_ring_patterns").select("*").eq("claim_id", claim.id),
      ]);

      const historicalMatches = (edges.data ?? [])
        .filter((e) => e.relationship_type === "historical_match")
        .map((e) => e.properties);

      const payload = {
        claim_id: claim.claim_id,
        generated_at: new Date().toISOString(),
        claim: claimRow.data,
        score: {
          risk_score: sqc.data?.risk_score,
          risk_category: sqc.data?.risk_category,
          recommended_action: sqc.data?.recommended_action,
          component_scores: sqc.data?.component_scores,
          key_findings: sqc.data?.key_findings,
          narrative: sqc.data?.narrative,
        },
        fields: fields.data ?? [],
        facts: facts.data ?? [],
        rules_triggered: rules.data ?? [],
        contradictions: contras.data ?? [],
        fraud_ring_patterns: fraud.data ?? [],
        resolved_entities: resolved.data ?? [],
        entity_nodes: nodes.data ?? [],
        historical_matches: historicalMatches,
        document_checklist: checklist.data ?? [],
        investigation_questions: questions.data ?? [],
      };

      if (sqc.data?.id) {
        await sb
          .from("sqc_results")
          .update({ final_payload: payload as never })
          .eq("id", sqc.data.id);
      }
      break;
    }
  }
}

function summarizeStep(step: StepDef, scenario: ScenarioOutput): Record<string, unknown> {
  switch (step.tool) {
    case "ocr.extract":
      return { documents: scenario.documents.length };
    case "field.extract":
      return { count: scenario.documents.reduce((a, d) => a + d.fields.length, 0) };
    case "fact.generate":
      return { count: scenario.documents.reduce((a, d) => a + d.facts.length, 0) };
    case "rule.evaluate":
      return { triggered: scenario.triggered_rules.length };
    case "contradiction.compare":
      return { count: scenario.contradictions.length };
    case "entity.extract":
      return { mentions: scenario.documents.reduce((a, d) => a + d.entity_mentions.length, 0) };
    case "entity.resolve":
      return { resolved: scenario.resolved_entities.length };
    case "fraud.detect":
      return { patterns: scenario.fraud_ring_patterns.length };
    case "score.calculate":
      return {
        risk_score: scenario.score.risk_score,
        risk_category: scenario.score.risk_category,
        action: scenario.score.recommended_action,
      };
    case "questions.generate":
      return { count: scenario.questions.length };
    case "checklist.build":
      return { items: scenario.checklist.length };
    default:
      return {};
  }
}

export const getJobEvents = createServerFn({ method: "GET" })
  .inputValidator((input) => z.object({ claimId: z.string().uuid() }).parse(input))
  .handler(async ({ data }) => {
    const sb = supabaseAdmin;
    const [events, sqc] = await Promise.all([
      sb
        .from("job_events")
        .select("*")
        .eq("claim_id", data.claimId)
        .order("created_at", { ascending: true })
        .limit(500),
      sb
        .from("sqc_results")
        .select("*")
        .eq("claim_id", data.claimId)
        .order("created_at", { ascending: false })
        .limit(1)
        .maybeSingle(),
    ]);
    return { events: events.data ?? [], sqc: sqc.data ?? null };
  });
