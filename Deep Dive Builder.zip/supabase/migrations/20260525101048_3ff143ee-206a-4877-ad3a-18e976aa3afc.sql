
-- Evidence trail columns on triggered_rules
ALTER TABLE public.triggered_rules
  ADD COLUMN IF NOT EXISTS source_fact_ids uuid[] DEFAULT '{}'::uuid[],
  ADD COLUMN IF NOT EXISTS source_field_ids uuid[] DEFAULT '{}'::uuid[],
  ADD COLUMN IF NOT EXISTS source_document_ids uuid[] DEFAULT '{}'::uuid[],
  ADD COLUMN IF NOT EXISTS min_source_confidence numeric;

-- Evidence trail columns on contradictions
ALTER TABLE public.contradictions
  ADD COLUMN IF NOT EXISTS source_fact_ids uuid[] DEFAULT '{}'::uuid[],
  ADD COLUMN IF NOT EXISTS source_field_ids uuid[] DEFAULT '{}'::uuid[],
  ADD COLUMN IF NOT EXISTS source_document_ids uuid[] DEFAULT '{}'::uuid[],
  ADD COLUMN IF NOT EXISTS min_source_confidence numeric;

-- New table for detected fraud-ring patterns
CREATE TABLE IF NOT EXISTS public.fraud_ring_patterns (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  claim_id uuid NOT NULL,
  pattern_type text NOT NULL,
  pattern_name text NOT NULL,
  severity text NOT NULL,
  description text,
  explanation text,
  shared_entity_ids jsonb NOT NULL DEFAULT '[]'::jsonb,
  historical_claim_ids jsonb NOT NULL DEFAULT '[]'::jsonb,
  confidence numeric DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.fraud_ring_patterns ENABLE ROW LEVEL SECURITY;

CREATE POLICY "demo_read_fraud_ring_patterns" ON public.fraud_ring_patterns FOR SELECT USING (true);
CREATE POLICY "demo_write_fraud_ring_patterns" ON public.fraud_ring_patterns FOR INSERT WITH CHECK (true);
CREATE POLICY "demo_update_fraud_ring_patterns" ON public.fraud_ring_patterns FOR UPDATE USING (true) WITH CHECK (true);
CREATE POLICY "demo_delete_fraud_ring_patterns" ON public.fraud_ring_patterns FOR DELETE USING (true);

-- Grounded questions: add source linkage + workflow columns
ALTER TABLE public.proactive_questions
  ADD COLUMN IF NOT EXISTS source_type text,
  ADD COLUMN IF NOT EXISTS source_rule_id uuid,
  ADD COLUMN IF NOT EXISTS source_contradiction_id uuid,
  ADD COLUMN IF NOT EXISTS source_fraud_pattern_id uuid,
  ADD COLUMN IF NOT EXISTS directed_to text,
  ADD COLUMN IF NOT EXISTS next_steps jsonb DEFAULT '[]'::jsonb,
  ADD COLUMN IF NOT EXISTS min_source_confidence numeric;
