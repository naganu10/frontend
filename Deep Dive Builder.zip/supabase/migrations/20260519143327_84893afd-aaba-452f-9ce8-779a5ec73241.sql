
-- ============ CORE CLAIM TABLES ============
CREATE TABLE public.claims (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  claim_id TEXT NOT NULL UNIQUE,
  claim_type TEXT NOT NULL DEFAULT 'OD',
  policy_number TEXT,
  claim_amount NUMERIC,
  incident_date DATE,
  incident_time TIME,
  policy_start_date DATE,
  policy_end_date DATE,
  vehicle_registration_number TEXT,
  insured_name TEXT,
  claimant_name TEXT,
  driver_name TEXT,
  garage_name TEXT,
  hospital_name TEXT,
  incident_location TEXT,
  status TEXT NOT NULL DEFAULT 'pending',
  is_demo BOOLEAN NOT NULL DEFAULT false,
  demo_scenario TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.claim_documents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  claim_id UUID NOT NULL REFERENCES public.claims(id) ON DELETE CASCADE,
  file_name TEXT NOT NULL,
  document_type TEXT NOT NULL,
  detected_language TEXT DEFAULT 'en',
  translation_required BOOLEAN DEFAULT false,
  translated_text TEXT,
  extracted_text TEXT,
  classification_confidence NUMERIC DEFAULT 0,
  storage_path TEXT,
  warnings JSONB DEFAULT '[]'::jsonb,
  status TEXT NOT NULL DEFAULT 'pending',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.extracted_fields (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  claim_id UUID NOT NULL REFERENCES public.claims(id) ON DELETE CASCADE,
  document_id UUID REFERENCES public.claim_documents(id) ON DELETE CASCADE,
  field_name TEXT NOT NULL,
  raw_value TEXT,
  normalized_value TEXT,
  confidence NUMERIC DEFAULT 0,
  field_uuid TEXT NOT NULL,
  source_language TEXT DEFAULT 'en',
  used_in_rule BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.extracted_facts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  claim_id UUID NOT NULL REFERENCES public.claims(id) ON DELETE CASCADE,
  fact_text TEXT NOT NULL,
  fact_type TEXT,
  source_document_id UUID REFERENCES public.claim_documents(id) ON DELETE SET NULL,
  source_field_ids JSONB DEFAULT '[]'::jsonb,
  confidence NUMERIC DEFAULT 0,
  used_in_contradiction BOOLEAN DEFAULT false,
  used_in_rule BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ============ RULES ============
CREATE TABLE public.master_rules (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  rule_id TEXT NOT NULL UNIQUE,
  rule_name TEXT NOT NULL,
  category TEXT NOT NULL,
  severity TEXT NOT NULL,
  description TEXT,
  data_required JSONB DEFAULT '[]'::jsonb,
  rule_type TEXT,
  is_active BOOLEAN NOT NULL DEFAULT false,
  used_in_demo BOOLEAN NOT NULL DEFAULT false,
  threshold_config JSONB DEFAULT '{}'::jsonb,
  source TEXT NOT NULL DEFAULT 'default',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.uploaded_master_rules (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  rule_id TEXT NOT NULL,
  rule_name TEXT NOT NULL,
  category TEXT NOT NULL,
  severity TEXT NOT NULL,
  description TEXT,
  data_required JSONB DEFAULT '[]'::jsonb,
  rule_type TEXT,
  batch_id UUID NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.triggered_rules (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  claim_id UUID NOT NULL REFERENCES public.claims(id) ON DELETE CASCADE,
  rule_id TEXT NOT NULL,
  rule_name TEXT NOT NULL,
  category TEXT,
  severity TEXT NOT NULL,
  description TEXT,
  evidence JSONB DEFAULT '{}'::jsonb,
  confidence NUMERIC DEFAULT 1,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ============ CONTRADICTIONS ============
CREATE TABLE public.contradictions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  claim_id UUID NOT NULL REFERENCES public.claims(id) ON DELETE CASCADE,
  contradiction_type TEXT NOT NULL,
  severity TEXT NOT NULL,
  description TEXT NOT NULL,
  documents_involved JSONB DEFAULT '[]'::jsonb,
  facts_involved JSONB DEFAULT '[]'::jsonb,
  explanation TEXT,
  recommended_followup TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ============ GUIDANCE ============
CREATE TABLE public.proactive_questions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  claim_id UUID NOT NULL REFERENCES public.claims(id) ON DELETE CASCADE,
  question TEXT NOT NULL,
  target TEXT,
  priority TEXT,
  rationale TEXT,
  trigger_reference TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.document_checklist (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  claim_id UUID NOT NULL REFERENCES public.claims(id) ON DELETE CASCADE,
  document_type TEXT NOT NULL,
  mandatory BOOLEAN NOT NULL DEFAULT false,
  reason TEXT,
  suggested_source TEXT,
  status TEXT NOT NULL DEFAULT 'missing',
  trigger_reference TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ============ HISTORICAL ============
CREATE TABLE public.historical_claims (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  historical_claim_id TEXT NOT NULL UNIQUE,
  claim_type TEXT,
  vehicle_registration_number TEXT,
  claimant_name TEXT,
  driver_name TEXT,
  garage_name TEXT,
  hospital_name TEXT,
  incident_location TEXT,
  claim_amount NUMERIC,
  incident_date DATE,
  risk_category TEXT,
  investigation_outcome TEXT,
  suspicious_flag BOOLEAN DEFAULT false,
  pattern_notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ============ ENTITY GRAPH ============
CREATE TABLE public.entity_nodes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  claim_id UUID NOT NULL REFERENCES public.claims(id) ON DELETE CASCADE,
  node_key TEXT NOT NULL,
  node_type TEXT NOT NULL,
  label TEXT NOT NULL,
  properties JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.entity_edges (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  claim_id UUID NOT NULL REFERENCES public.claims(id) ON DELETE CASCADE,
  source_node_id UUID NOT NULL REFERENCES public.entity_nodes(id) ON DELETE CASCADE,
  target_node_id UUID NOT NULL REFERENCES public.entity_nodes(id) ON DELETE CASCADE,
  relationship_type TEXT NOT NULL,
  properties JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ============ RESULTS + JOB EVENTS ============
CREATE TABLE public.sqc_results (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  claim_id UUID NOT NULL REFERENCES public.claims(id) ON DELETE CASCADE,
  job_id TEXT NOT NULL UNIQUE,
  risk_score NUMERIC NOT NULL DEFAULT 0,
  risk_category TEXT,
  recommended_action TEXT,
  component_scores JSONB DEFAULT '{}'::jsonb,
  key_findings JSONB DEFAULT '[]'::jsonb,
  narrative TEXT,
  final_payload JSONB DEFAULT '{}'::jsonb,
  status TEXT NOT NULL DEFAULT 'pending',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.job_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  job_id TEXT NOT NULL,
  claim_id UUID REFERENCES public.claims(id) ON DELETE CASCADE,
  phase TEXT,
  agent_name TEXT,
  skill_applied TEXT,
  tool_used TEXT,
  status TEXT NOT NULL,
  message TEXT,
  payload JSONB DEFAULT '{}'::jsonb,
  started_at TIMESTAMPTZ,
  completed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_job_events_job_id ON public.job_events(job_id);
CREATE INDEX idx_job_events_created_at ON public.job_events(created_at);

-- ============ SKILLS + TOOLS REGISTRY ============
CREATE TABLE public.skills (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  skill_name TEXT NOT NULL UNIQUE,
  purpose TEXT,
  instructions TEXT,
  applied_by_agent TEXT,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.tools_registry (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tool_name TEXT NOT NULL UNIQUE,
  description TEXT,
  input_schema JSONB DEFAULT '{}'::jsonb,
  output_schema JSONB DEFAULT '{}'::jsonb,
  deterministic BOOLEAN NOT NULL DEFAULT true,
  contains_reasoning BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ============ APP CONFIG (singleton-style key/value) ============
CREATE TABLE public.app_config (
  key TEXT PRIMARY KEY,
  value JSONB NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
INSERT INTO public.app_config (key, value) VALUES
  ('processing_mode', '"demo"'::jsonb),
  ('rules_source', '"default"'::jsonb),
  ('active_uploaded_batch', 'null'::jsonb);

-- ============ ENABLE RLS WITH PERMISSIVE POLICIES (no auth in v1) ============
DO $$
DECLARE
  t TEXT;
BEGIN
  FOR t IN
    SELECT unnest(ARRAY[
      'claims','claim_documents','extracted_fields','extracted_facts',
      'master_rules','uploaded_master_rules','triggered_rules','contradictions',
      'proactive_questions','document_checklist','historical_claims',
      'entity_nodes','entity_edges','sqc_results','job_events',
      'skills','tools_registry','app_config'
    ])
  LOOP
    EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY;', t);
    EXECUTE format('CREATE POLICY "demo_read_%s" ON public.%I FOR SELECT USING (true);', t, t);
    EXECUTE format('CREATE POLICY "demo_write_%s" ON public.%I FOR INSERT WITH CHECK (true);', t, t);
    EXECUTE format('CREATE POLICY "demo_update_%s" ON public.%I FOR UPDATE USING (true) WITH CHECK (true);', t, t);
    EXECUTE format('CREATE POLICY "demo_delete_%s" ON public.%I FOR DELETE USING (true);', t, t);
  END LOOP;
END $$;

-- ============ REALTIME for job_events ============
ALTER PUBLICATION supabase_realtime ADD TABLE public.job_events;

-- ============ STORAGE BUCKET ============
INSERT INTO storage.buckets (id, name, public)
VALUES ('claim-documents', 'claim-documents', true)
ON CONFLICT (id) DO NOTHING;

CREATE POLICY "claim_docs_public_read"
  ON storage.objects FOR SELECT
  USING (bucket_id = 'claim-documents');

CREATE POLICY "claim_docs_public_write"
  ON storage.objects FOR INSERT
  WITH CHECK (bucket_id = 'claim-documents');

CREATE POLICY "claim_docs_public_update"
  ON storage.objects FOR UPDATE
  USING (bucket_id = 'claim-documents');

CREATE POLICY "claim_docs_public_delete"
  ON storage.objects FOR DELETE
  USING (bucket_id = 'claim-documents');
